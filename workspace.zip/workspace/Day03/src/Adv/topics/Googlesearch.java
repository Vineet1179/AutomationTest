package Adv.topics;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;

public class Googlesearch {

	public static void main(String[] args) throws InterruptedException {
		WebDriver driver= new FirefoxDriver();
		driver.manage().window().maximize();
		driver.get("http://google.com");
		
		WebElement we=driver.findElement(By.id("lst-ib"));
		we.sendKeys("Selenium");
		Thread.sleep(3000);
		we.sendKeys(Keys.DOWN);
		we.sendKeys(Keys.DOWN);
		we.sendKeys(Keys.ENTER);
		
		
	
		

	}

}
