package Adv.topics;

import java.io.FileInputStream;
import java.util.Properties;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class Properties_class {

	public static void main(String[] args) {
		try {
			FileInputStream fi=new
					FileInputStream("testData\\inputdata.properties");
			Properties obj=new Properties();
			obj.load(fi);
			//Application _launch
			String url= obj.getProperty("App_url");
			WebDriver driver=new FirefoxDriver();
			driver.get(url);
			driver.manage().window().maximize();
			//Admin_login
			String username=obj.getProperty("A_username");
			String password=obj.getProperty("A_password");
			String login=obj.getProperty("A_login");
			String uid=obj.getProperty("A_uid");
			String pwd=obj.getProperty("A_pwd");
			driver.findElement(By.id(username)).sendKeys(uid);
			driver.findElement(By.id(password)).sendKeys(pwd);
			driver.findElement(By.id(login)).click();
			String newbranchbutton=obj.getProperty("//img[@src='images/emp_btn.jpg']");
			String branchname=obj.getProperty("br_branchname");
			String Address1=obj.getProperty("br_Address1");
			String Address2=obj.getProperty("br_Address2");
			String Address3=obj.getProperty("Br_Address3");
			String Area=obj.getProperty("Br_Area");
			String ZipCode=obj.getProperty("br_ZipCode");
			String Country=obj.getProperty("Br_Country");
			String State=obj.getProperty("Br_state");
			String city=obj.getProperty("Br_city");
			driver.findElement(By.id(branchname)).sendKeys(branchname);
			
			
			
			
			
			
			
			
			
		} catch (Exception e) {
			// TODO: handle exception
		}
	}

}
