package Adv.topics;

public class InputRoles_class2 {
	
	
	public static String RoleName="Smith";
	public static String RoleDesc="manager";
	public static String RoleType="E" ;
	

}
