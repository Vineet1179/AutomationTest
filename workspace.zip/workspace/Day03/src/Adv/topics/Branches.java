package Adv.topics;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;

public class Branches {

	public static void main(String[] args) {
		WebDriver driver= new FirefoxDriver();
		 driver.get("http://srssprojects.in/home.aspx");
	       driver.findElement(By.id("txtuId")).sendKeys("Admin");
	       driver.findElement(By.id("txtPword")).sendKeys("Admin");
	       driver.findElement(By.id("login")).click();
	       
		driver.findElement(By.xpath("//img[@src='images/Branches_but.jpg']")).click();
		driver.findElement(By.id("BtnNewBR")).click();
		driver.findElement(By.id("txtbName")).sendKeys("Glasgow");
		driver.findElement(By.id("txtAdd1")).sendKeys("123 hope st");
        driver.findElement(By.id("Txtadd2")).sendKeys("hfie");
        driver.findElement(By.id("txtadd3")).sendKeys("uegfu");
        driver.findElement(By.id("txtArea")).sendKeys("Lark");
        driver.findElement(By.id("txtZip")).sendKeys("g6 2jj");
        new Select(driver.findElement(By.id("lst_counrtyU"))).selectByVisibleText("UK");
        new Select(driver.findElement(By.id("lst_stateI"))).selectByVisibleText("England");
        new Select(driver.findElement(By.id("lst_cityI"))).selectByVisibleText("LONDON");
        driver.findElement(By.id("btn_insert")).click();
        driver.switchTo().alert().accept();
        
	}

}
