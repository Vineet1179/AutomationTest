package Adv.topics;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;

public class Roles {

	public static void main(String[] args) {
		WebDriver driver= new FirefoxDriver();
		 driver.get("http://srssprojects.in/home.aspx");
	       driver.findElement(By.id("txtuId")).sendKeys("Admin");
	       driver.findElement(By.id("txtPword")).sendKeys("Admin");
	       driver.findElement(By.id("login")).click();
	       
	       driver.findElement(By.xpath("//img[@src='images/Roles_but.jpg']")).click();
	       driver.findElement(By.id("btnRoles")).click();
	       driver.findElement(By.id("txtRname")).sendKeys("Smith");
	       driver.findElement(By.id("txtRDesc")).sendKeys("manager");
	       new Select(driver.findElement(By.id("lstRtypeN"))).selectByVisibleText("E");
	       driver.findElement(By.id("btninsert")).click();
	       driver.switchTo().alert().accept();
	       

	}

}
