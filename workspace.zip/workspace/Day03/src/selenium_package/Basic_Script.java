package selenium_package;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;

public class Basic_Script {

	public static void main(String[] args) throws InterruptedException {
	//Application********************
		WebDriver driver=new FirefoxDriver();
		driver.get("http://srssprojects.in/home.aspx");
		driver.manage().window().maximize();
	//Admin login *****************
		driver.findElement(By.id("txtuId")).sendKeys("Admin");
		driver.findElement(By.id("txtPword")).sendKeys("Admin");
		driver.findElement(By.id("login")).click();
		driver.findElement(By.xpath("//img[@src='images/Branches_but.jpg']")).click();
		driver.findElement(By.xpath("//input[@src='images/NewBranch.jpg']")).click();
		driver.findElement(By.id("txtbName")).sendKeys("mindq2345");
		driver.findElement(By.id("txtAdd1")).sendKeys("mjuy6789");
        driver.findElement(By.id("Txtadd2")).sendKeys("derthyry");
        driver.findElement(By.id("txtadd3")).sendKeys("hidfhi");
        driver.findElement(By.id("txtArea")).sendKeys("boebf");
        driver.findElement(By.id("txtZip")).sendKeys("12345");
        new Select(driver.findElement(By.id("lst_counrtyU"))).selectByVisibleText("INDIA");
        new Select(driver.findElement(By.id("lst_stateI"))).selectByVisibleText("GOA");
        Thread.sleep(2000);
        new Select(driver.findElement(By.id("lst_cityI"))).selectByVisibleText("GOA");
        driver.findElement(By.id("btn_insert")).click();
        driver.switchTo().alert().accept();
          
        
        
		
		

	}

}
