package Webtable_package;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class Webtable_package {

	
	public static boolean flag;
	public static int column;
	public static void Branch_Edit(WebDriver driver, String Tableid, String xpath ,String Recordname,int columnNo)
	{
		try {
			WebElement linktext=driver.findElement(By.xpath(xpath));
			String linkrow= linktext.getText();
			System.out.println(linkrow);
			String link[]=linkrow.split(" ");
			for (int i = 1; i < link.length; i++) 
				
			
			{
				WebElement Tableid1=driver.findElement(By.id(Tableid));
				List<WebElement>rows=Tableid1.findElements(By.tagName("tr"));
				for(WebElement eachrow:rows)
				{
					List<WebElement>col=eachrow.findElements(By.tagName("td"));
					int column=1;
					
							for( WebElement cell :col)
							{
								String celldata=cell.getText();
								if (celldata.matches(Recordname))
								{
								flag=true;
								}
								if(flag=true)
								{
									if(column ==columnNo)
									{
										System.out.println("match found"+column);
										cell.findElement(By.tagName("a")).click();
									}
									column=column+1;
									}
								}
							}
			if(flag=true){
				break;
			}
			driver.findElement(By.linkText(link[i])).click();
			}
		}
			catch (Exception e) {
				System.out.println();
			}
			
			}
			
			
		} catch (Exception e) {
			// TODO: handle exception
		}
	}
}
