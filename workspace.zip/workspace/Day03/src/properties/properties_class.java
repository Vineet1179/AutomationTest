package properties;

import java.io.FileInputStream;
import java.util.Properties;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class properties_class {

	private static final String Rolename = null;

	public static void main(String[] args) {
	
		try {
			FileInputStream fi=new
			FileInputStream("TestData\\inoutdata.properties");
			Properties Repo=new Properties();
			Repo.load(fi);
			String url=Repo.getProperty("App_url");
			//open Application************
			WebDriver driver= new FirefoxDriver();
			driver.get(url);
			driver.manage().window().maximize();
			//Admin Login ***********
			String username=Repo.getProperty("A_id");
			String password=Repo.getProperty("p_id");
			String log=Repo.getProperty("A_login");
			String uid=Repo.getProperty("A_uid");
			String pwd=Repo.getProperty("A_pwd");
			
			driver.findElement(By.id(username)).sendKeys(uid);
			driver.findElement(By.id(password)).sendKeys(pwd);
            driver.findElement(By.id(log)).click();
            //Branches********
            String Branches=Repo.getProperty("//img[@src='images/Branches_but.jpg']");
            String NewBranch=Repo.getProperty("Br_NewBranch");
            String Branchname=Repo.getProperty("Br_Branchname");
            String Address1=Repo.getProperty("Br_Address1");
            String Address2=Repo.getProperty("Br_Address2");
            String Address3=Repo.getProperty("Br_Address3");
            String Area=Repo.getProperty("Br_Area");
            String ZipCode=Repo.getProperty("Br_ZipCode");
            String Country=Repo.getProperty("Br_Country");
            String State=Repo.getProperty("Br_State");
            String City=Repo.getProperty("Br_City");
                        
            driver.findElement(By.id(Branchname)).sendKeys(Branchname);
            driver.findElement(By.id(Address1)).sendKeys(Address1);
            driver.findElement(By.id(Address2)).sendKeys(Address2);
            driver.findElement(By.id(Address3)).sendKeys(Address3);
            driver.findElement(By.id(Area)).sendKeys(Area);
            driver.findElement(By.id(ZipCode)).sendKeys(ZipCode);
            driver.findElement(By.id(Country)).sendKeys(Country);
            driver.findElement(By.id(State)).sendKeys(State);
            driver.findElement(By.id(City)).sendKeys(City);
                        
            //Roles
            String Newrole=Repo.getProperty("R_Roles");
            String RoleName=Repo.getProperty("R_RoleName");
            String RoleDescription=Repo.getProperty("R_RoleDesc");
            String RoleType=Repo.getProperty("RoleType");
            String Submit=Repo.getProperty("R_Submit");
            
          driver.findElement(By.id(RoleName)).sendKeys(Rolename);
          driver.findElement(By.id(RoleDescription)).sendKeys(RoleDescription);
          driver.findElement(By.id(RoleType)).sendKeys(RoleType);
          driver.findElement(By.id(Submit)).click();
          
          //Employees
  
          String Employee=Repo.getProperty("E_Employee");
          String NewEmployee=Repo.getProperty("E-NewEmployee");
          String EmloyerName=Repo.getProperty("E_EmloyerName");
          String LoginPassword=Repo.getProperty("E_LoginPassword");
          String Role=Repo.getProperty("E_Role");
          String Branch=Repo.getProperty("E_Branch");
          
          driver.findElement(By.id(Employee)).click();
          driver.findElement(By.id(NewEmployee)).click();
          driver.findElement(By.id(EmloyerName)).sendKeys(EmloyerName);
          driver.findElement(By.id(LoginPassword)).sendKeys(LoginPassword);          
          driver.findElement(By.id(Role)).sendKeys(Role);
          driver.findElement(By.id(Branch)).sendKeys(Branch);
          driver.findElement(By.id(Submit)).click();
          
          
          
          
            
            
            
            
            
            
            
            
            
            
            
            
			
			
			
			
			
			
		} catch (Exception e) {
			// TODO: handle exception
		}

	}

}
