package Excel_package;


import org.testng.Reporter;
import org.testng.annotations.Test;

public class Excel_testable {
	@Test(priority=0)
	public void Application ()
	{
		Helper_class.excel_helper_class("Excel_inputdata.xls","URL");
		Reporter.log("Application is pass",true);
	}
	@Test(priority=1)
	public void Admin_login()
	{
		Helper_class.excel_helper_class1("Excel_inputdata.xls","Admin");
		Reporter.log("Admin loginis pass",true);
		
		
	}

}
