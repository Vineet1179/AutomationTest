package Excel_package;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;

public class Helper_class {
public static WebDriver driver;
public static void excel_helper_class(String filename,String sheetname)
{
	Excel_connection.excel_connection_class(filename, sheetname);
	String app_url=Excel_connection.sht.getCell(0,1).getContents();
	driver=new FirefoxDriver();
	driver.get(app_url);
	driver.manage().window().maximize();
}
public static void excel_helper_class1(String filename, String sheetname)
{
	Excel_connection .excel_connection_class(filename, sheetname);

	for(int i= 1; i <Excel_connection.sht.getRows();i++)
	{
		String proname= Excel_connection.sht.getCell(1,i).getContents();
		String provalue =Excel_connection .sht.getCell(2,i).getContents();
		String action = Excel_connection.sht.getCell(3,i).getContents();
		String inputdata=Excel_connection.sht.getCell(4,i).getContents();
		switch(action)
		{
		
		case "TextBox":
			WebElement ele=driver.findElement(Excel_locators.excel_locators_class(proname, provalue));
			ele.sendKeys(inputdata);
			break;
		case "Button":
		WebElement ele1=driver.findElement(Excel_locators.excel_locators_class(proname, provalue));
		ele1.click();
		break;
		default:
			break;
			
		}
	}
}
}
