package Excel_package;

import org.openqa.selenium.By;

public class Excel_locators {
	
	public static By excel_locators_class(String proname,String provalue)
	{
		By obj=null;
		switch (proname)
		{
		case" id";
		obj=By.xpath(provalue);
		break;
		case "xpath";
		obj=By.xpath(provalue);
		break;
		case "name";
		obj=By.name(provalue);
		break;
		default: 
			break;
				
		
		}
	return obj;
	}

}
