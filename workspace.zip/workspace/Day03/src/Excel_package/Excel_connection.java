package Excel_package;

import java.io.FileInputStream;

import jxl.Sheet;
import jxl.Workbook;

public class Excel_connection {
	public static Workbook book;
	public static Sheet sht;
	public static String path="TestData\\";
	public static void excel_connection_class(String filename,String sheetname)
	{
		try {
			FileInputStream fi=new FileInputStream(path+filename);
			book=Workbook.getWorkbook(fi);
			sht=book.getSheet(sheetname);
			
		} catch (Exception e) {
		
		}
	}
	public static String excel_rows(int col,int row)
	{
		return sht.getCell(col,row).getContents();
	}




	}
	

}
