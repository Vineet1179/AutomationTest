import java.util.concurrent.TimeUnit;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select







public class AllTestCases {
	
	public static WebDriver driver;
	
	@Before
	public void start ()
	{
		
		System.out.println("I am in Before method");
	
	System.setProperty("webdriver.gecko.driver", "C:/Users/User/Desktop/Automation/Driver/geckodriver/geckodriver.exe");
	 driver=new FirefoxDriver();
	driver.get("https://tuclothing.sainsburys.co.uk/");
	Assert.assertEquals("Womens, Mens & Kids Fashion  | Tu clothing", driver.getTitle());
	driver.manage().window().maximize();	
	driver.manage().timeouts().implicitlyWait(5,TimeUnit.SECONDS);
	}
	@Test
	  public void searchWithValidData()
	  {
	   System.out.println("I am in Test1 method");
	   driver.findElement(By.id("search")).clear();
	   driver.findElement(By.id("search")).sendKeys("Men Jeans");
	   driver.findElement(By.xpath("//*[@id='search_form_input']/div/div[1]/button")).click();

}
	@Test
	  public void verifyAddToBasket()
	  {
	   driver.findElement(By.id("search")).clear();
	    driver.findElement(By.id("search")).sendKeys("womens jacket");
	    driver.findElement(By.xpath("//*[@id='search_form_input']/div/div[1]/button")).click();
	    driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	    driver.findElement(By.xpath("//*[@id='productContents']/div[1]/div/a[1]/span[2]")).click();
	    driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	    Select size=new Select(driver.findElement(By.xpath("//*[@id='Size']")));
	    
	    //size.selectByVisibleText("14");
	    size.selectByIndex(3);
	       Select qty=new Select(driver.findElement(By.xpath("//*[@id='qty']")));
	    qty.selectByIndex(2);
	      driver.findElement(By.xpath("//*[@id='addToCartButton']")).click(); 
	  }
	
	  
	@After
	  public void close()
	  {
	   System.out.println("I am in After method");
	   driver.quit();
	  }
}

