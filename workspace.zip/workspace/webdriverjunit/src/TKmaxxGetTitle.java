import java.util.concurrent.TimeUnit;

import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import junit.framework.Assert;

public class TKmaxxGetTitle {
	
	public static WebDriver driver;
	
	@Before
	public void start(){
		
		System.out.println(" I am Before method ");
		System.setProperty("webdriver.gecko.driver", "C:/Users/User/Desktop/Automation/Driver/geckodriver/geckodriver.exe");
		driver=new FirefoxDriver();
		driver.get("http://www.tkmaxx.com/");
		Assert.assertEquals("Home - TK Maxx",driver.getTitle());
		driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
		
		
		 
		
	}
	@Test
	public void searchWithValidData(){
		System.out.println("I am in Test method");
		driver.findElement(By.cssSelector(".header-row-two #q")).sendKeys("sunglasses");
        driver.findElement(By.cssSelector("#searchsubmit")).click();
		
	}

}
