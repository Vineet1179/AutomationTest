package tuproductdelivery;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;

public class GuestCustomerClickandCollectManualAdd {

	public static void main(String[] args) throws InterruptedException {
		System.setProperty("webdriver.gecko.driver", "C:/Users/User/Desktop/Automation/Driver/geckodriver/geckodriver.exe");
		WebDriver driver=new FirefoxDriver();
		driver.get("https://tuclothing.sainsburys.co.uk/");
		driver.manage().window().maximize();
		driver.findElement(By.xpath("//*[@id='nav_block']/li[2]/span/a")).click();
		Thread.sleep(3000);
		driver.findElement(By.linkText("Shoes & Boots")).click();
		Thread.sleep(3000);
		driver.findElement(By.xpath("//*[@id='filters']/div/div[3]/div[2]/div[1]/ul/li[1]/form/label/input")).click();
		Thread.sleep(3000);
		driver.findElement(By.xpath(".//*[@id='filters']/div[2]/div[4]/div[2]/div[1]/ul/li[2]/form/label/input")).click();
		Thread.sleep(3000);
		driver.findElement(By.xpath("//*[@id='productContents']/div[2]/div/a[1]/span[2]")).click();
		Thread.sleep(5000);
		Select shoe=new Select(driver.findElement(By.id("Size")));
		shoe.selectByIndex(2);
		Select qty=new Select(driver.findElement(By.id("qty")));
		qty.selectByIndex(1);
		driver.findElement(By.id("addToCartButton")).click();
		driver.findElement(By.xpath("//*[@id='cart_button']/a")).click();
		Thread.sleep(3000);
        driver.findElement(By.xpath("//*[@id='cart_button']/a")).click();
        Thread.sleep(3000);
        driver.findElement(By.id("guest_email")).sendKeys("testersrock@gmail.com");
        driver.findElement(By.xpath("//*[@id='guestForm']/div[3]/button")).click();
        Thread.sleep(3000);
        driver.findElement(By.xpath("//*[@id='delivery-options']/ul/li[1]/label")).click();
        driver.findElement(By.xpath("//*[@id='delivery-options']/input")).click();
        Thread.sleep(3000);
        driver.findElement(By.id("storelocator-query")).sendKeys("G521DB");
        driver.findElement(By.id("storeFinder")).click();
        Thread.sleep(3000);
        driver.findElement(By.xpath("//*[@id='selectStoreFormId']/ul/li[1]/label/span[3]")).click();
        Thread.sleep(3000);
        driver.findElement(By.xpath("//*[@id='delivery-options']/ul/li[1]/label/div/span[2]")).click();
        Thread.sleep(3000);
        driver.findElement(By.xpath("//*[@id='skip-to-content']/div[1]/div[2]/div/button")).click();
        Thread.sleep(3000);
        Select title= new Select(driver.findElement(By.id("newTitle")));
        title.selectByIndex(1);
        driver.findElement(By.id("newFirstName")).sendKeys("James");
        driver.findElement(By.id("newSurname")).sendKeys("Bond");
        driver.findElement(By.id("addressDeliveryhouseNameOrNumber")).sendKeys("House no. 23");
        driver.findElement(By.id("addressPostcode")).sendKeys("G521DB");
        driver.findElement(By.xpath("//*[@id='paymentDetailsForm']/div[3]/div[1]/div/div/div/div/div[5]/a/span[1]")).click();
        driver.findElement(By.id("addressDeliveryLine1")).sendKeys("1306 Paisley road west");
        driver.findElement(By.id("addressDeliveryLine2")).sendKeys("Opp.Bellahouton Park");
        driver.findElement(By.id("addressDeliveryTownCity")).sendKeys("Glasgow");
        Thread.sleep(3000);
		driver.findElement(By.id("contactPreferencesAnyId")).click();
		driver.findElement(By.id("termsAndConditionsId")).click();
		driver.findElement(By.id("contPayment")).click();
		
		
		
		
	}

}
