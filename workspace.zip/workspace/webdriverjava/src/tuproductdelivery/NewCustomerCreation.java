package tuproductdelivery;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;

public class NewCustomerCreation {

	public static void main(String[] args) throws InterruptedException {
		System.setProperty("webdriver.gecko.driver", "C:/Users/User/Desktop/Automation/Driver/geckodriver/geckodriver.exe");
		WebDriver driver=new FirefoxDriver();
		driver.get("https://tuclothing.sainsburys.co.uk/");
		driver.manage().window().maximize();
		driver.findElement(By.linkText("Tu Log In / Register")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@id='login-register-form']/div[2]/div[2]/div[2]/button")).click();
		driver.findElement(By.id("register_email")).sendKeys("bruce_wayne@hotmail.com");
		Select title=new Select(driver.findElement(By.id("register_title")));
		title.selectByIndex(1);
		driver.findElement(By.id("register_firstName")).sendKeys("Brucey");
		driver.findElement(By.id("register_lastName")).sendKeys("Wayner");
		driver.findElement(By.id("password")).sendKeys("IamBatman1");
		driver.findElement(By.id("register_checkPwd")).sendKeys("IamBatman1");
		driver.findElement(By.id("Terms & Conditions & Privacy Policy")).click();
		driver.findElement(By.xpath("//*[@id='tuRegisterForm']/div[7]/button")).click();
		
		
		
	}

}
