package tuproductdelivery;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;

public class NewCustomerStdFindAdd {

	public static void main(String[] args) throws InterruptedException {
		System.setProperty("webdriver.gecko.driver", "C:/Users/User/Desktop/Automation/Driver/geckodriver/geckodriver.exe");
		WebDriver driver=new FirefoxDriver();
		driver.get("https://tuclothing.sainsburys.co.uk/");
		driver.manage().window().maximize();
		driver.findElement(By.xpath("//*[@id='nav_block']/li[2]/span/a")).click();
		Thread.sleep(3000);
		driver.findElement(By.linkText("Belts")).click();
		Thread.sleep(3000);
		driver.findElement(By.xpath("//*[@id='productContents']/div[2]/div/a[1]/span[2]")).click();
		Thread.sleep(3000);
		Select size=new Select(driver.findElement(By.id("Size")));
		size.selectByIndex(2);
		Select qty=new Select(driver.findElement(By.id("qty")));
		qty.selectByIndex(1);
		driver.findElement(By.id("addToCartButton")).click();
		driver.findElement(By.xpath("//*[@id='cart_button']/a")).click();
		Thread.sleep(3000);
		driver.findElement(By.id("basketButtonTop")).click();
		
		

	}

}
