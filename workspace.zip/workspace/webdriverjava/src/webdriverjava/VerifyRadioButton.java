package webdriverjava;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class VerifyRadioButton {

	public static void main(String[] args) {
		System.setProperty("webdriver.gecko.driver", "C:/Users/User/Desktop/Automation/Driver/geckodriver/geckodriver.exe");
		WebDriver driver=new FirefoxDriver();
		driver.get("https://tuclothing.sainsburys.co.uk/");
		driver.manage().window().maximize();
		driver.findElement(By.xpath("//*[@id='search_form_input']/div/div[2]/label[2]")).click();
		
		
		
		
	}

}
