package webdriverjava;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class VerifyLogoutImage {

	public static void main(String[] args) throws InterruptedException {
		System.setProperty("webdriver.gecko.driver", "C:/Users/User/Desktop/Automation/Driver/geckodriver/geckodriver.exe");
		WebDriver driver=new FirefoxDriver();
		driver.get("https://tuclothing.sainsburys.co.uk/");
		driver.manage().window().maximize();
		driver.findElement(By.linkText("Tu Log In / Register")).click();
		Thread.sleep(3000);
		driver.findElement(By.xpath("//*[@id='login-register-form']/div[2]/div[2]/div[2]/button")).click();
        driver.findElement(By.id("j_username")).sendKeys("vineetmuley11@gmail.com");
        driver.findElement(By.id("j_password")).sendKeys("selenium1");
        driver.findElement(By.xpath("//*[@id='loginForm']/div[2]/button")).click();
        Thread.sleep(3000);
        driver.findElement(By.linkText("Log Out")).click();
	}

}
