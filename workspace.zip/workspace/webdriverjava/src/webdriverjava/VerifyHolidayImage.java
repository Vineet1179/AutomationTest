package webdriverjava;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;

public class VerifyHolidayImage {

	public static void main(String[] args) throws InterruptedException {
		System.setProperty("webdriver.gecko.driver", "C:/Users/User/Desktop/Automation/Driver/geckodriver/geckodriver.exe");
		WebDriver driver=new FirefoxDriver();
		driver.get("https://tuclothing.sainsburys.co.uk/");
		driver.manage().window().maximize();
		driver.findElement(By.linkText("Holiday")).click();
		Thread.sleep(3000);
		driver.findElement(By.xpath("//*[@id='nav_block']/li[8]/ul/li/div/ul/li/ul[1]/li[2]/ul[1]/li[1]/a")).click();
        Thread.sleep(3000);
        driver.findElement(By.xpath("//*[@id='filters']/div/div[4]/div[2]/div[1]/ul/li[1]/form/label/input")).click();
        
       
        
}
	
	
}

