package webdriverjava;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class VerifyTuStoreLocator {

	public static void main(String[] args) throws InterruptedException {
		System.setProperty("webdriver.gecko.driver", "C:/Users/User/Desktop/Automation/Driver/geckodriver/geckodriver.exe");
		WebDriver driver=new FirefoxDriver();
		driver.get("https://tuclothing.sainsburys.co.uk/");
		driver.manage().window().maximize();
		driver.findElement(By.linkText("Tu Store Locator")).click();
		Thread.sleep(3000);
		driver.findElement(By.id("women")).click();
		driver.findElement(By.id("men")).click();
		driver.findElement(By.id("children")).click();
		driver.findElement(By.id("gok")).click();
		driver.findElement(By.id("click")).click();
		driver.findElement(By.xpath("//*[@id='tuStoreFinderForm']/div[1]/div[2]/input")).clear();
		driver.findElement(By.xpath("//*[@id='tuStoreFinderForm']/div[1]/div[2]/input")).sendKeys("G537PH");
		driver.findElement(By.xpath("//*[@id='tuStoreFinderForm']/div[1]/button")).click();
	}

}
