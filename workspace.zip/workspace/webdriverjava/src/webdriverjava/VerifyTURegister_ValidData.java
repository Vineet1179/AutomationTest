package webdriverjava;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;

public class VerifyTURegister_ValidData {

	public static void main(String[] args) throws InterruptedException {
		System.setProperty("webdriver.gecko.driver", "C:/Users/User/Desktop/Automation/Driver/geckodriver/geckodriver.exe");
		WebDriver driver=new FirefoxDriver();
		driver.get("https://tuclothing.sainsburys.co.uk/");
		driver.manage().window().maximize();
		driver.findElement(By.linkText("Tu Log In / Register")).click();
		Thread.sleep(3000);
		driver.findElement(By.xpath("//*[@id='login-register-form']/div[2]/div[2]/div[2]/button")).click();
		driver.findElement(By.id("register_email")).sendKeys("vineetmuley11@gmail.com");
		Select we =new Select(driver.findElement(By.id("register_title")));
		we.selectByVisibleText("Mr");
		driver.findElement(By.id("register_firstName")).sendKeys("Vineet");
		driver.findElement(By.id("register_lastName")).sendKeys("Muley");
		driver.findElement(By.id("password")).sendKeys("selenium1");
		driver.findElement(By.xpath("//*[@id='tuRegisterForm']/div[1]/div[8]/div[2]/a")).click();
		driver.findElement(By.id("register_checkPwd")).sendKeys("selenium1");
		driver.findElement(By.id("regNectarPointsOne")).sendKeys("31925800");
		driver.findElement(By.id("regNectarPointsTwo")).sendKeys("065");
		driver.findElement(By.xpath("//*[@id='tuRegisterForm']/div[2]/div/div/label")).click();
		driver.findElement(By.id("Terms & Conditions & Privacy Policy")).click();
		driver.findElement(By.xpath("//*[@id='tuRegisterForm']/div[7]/button")).click();
		
		
		
		
		
		

	}

}
