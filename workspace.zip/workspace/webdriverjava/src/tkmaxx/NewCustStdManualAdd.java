package tkmaxx;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;

public class NewCustStdManualAdd {

	public static void main(String[] args) {
		System.setProperty("webdriver.gecko.driver", "C:/Users/User/Desktop/Automation/Driver/geckodriver/geckodriver.exe");
		WebDriver driver=new FirefoxDriver();
		driver.get("http://www.tkmaxx.com/");
		driver.manage().window().maximize();
		driver.findElement(By.cssSelector(".header-row-two #q")).sendKeys("sunglasses");
        driver.findElement(By.cssSelector("#searchsubmit")).click();
        driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
        driver.findElement(By.cssSelector("#details-13201036 #comp-name13201036")).click();
        driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
        Select qty=new Select(driver.findElement(By.cssSelector("#qtybox .js-qty")));
        qty.selectByIndex(1);   
        driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
        driver.findElement(By.cssSelector(".js-addproduct")).click();
        driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
        driver.findElement(By.cssSelector(".notifyBox #checkout")).click();
        driver.findElement(By.cssSelector(".new-customer .button")).click();
        Select title=new Select(driver.findElement(By.cssSelector("#billingaddressadd #title")));
        title.selectByVisibleText("Mr");
        driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
        driver.findElement(By.cssSelector(".row #fname")).sendKeys("Thomas");
        driver.findElement(By.cssSelector(".row #lname")).sendKeys("Smith");
        driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
        Select gender=new Select(driver.findElement(By.cssSelector(".form-select")));
        gender.selectByVisibleText("Male");
        Select day=new Select(driver.findElement(By.cssSelector("#billingaddressadd .form-half-input")));
        day.selectByVisibleText("4");
        driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
        Select month=new Select(driver.findElement(By.cssSelector("select[name='remmonth1']")));
        month.selectByVisibleText("April");
        driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
        Select year=new Select(driver.findElement(By.cssSelector("select[name='remyear']")));
        year.selectByVisibleText("1974");
        driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
        Select cntry=new Select(driver.findElement(By.cssSelector("#cntrylist")));
        cntry.selectByVisibleText("United Kingdom");
      
       // driver.findElement(By.cssSelector("#zipc")).sendKeys("G53 7PH");
        driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
        driver.findElement(By.cssSelector("#js-manual-reset-btn")).click();
        driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
        driver.findElement(By.cssSelector("#num")).sendKeys("27");
        driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
        driver.findElement(By.cssSelector("#addr1")).sendKeys("Gamrie Gardens");
        driver.findElement(By.cssSelector("#addr2")).sendKeys("Main door");
        driver.findElement(By.cssSelector("#city")).sendKeys("Glasgow");
        driver.findElement(By.cssSelector("#statetext")).sendKeys("United Kingdom");
        driver.findElement(By.cssSelector("#zipc")).sendKeys("G53 7PH");
        driver.findElement(By.cssSelector("#phone")).sendKeys("07871378993");
        driver.findElement(By.cssSelector("#usemail")).sendKeys("test10090@gmail.com");
        driver.findElement(By.cssSelector("#uspswd")).sendKeys("testing06");
        driver.findElement(By.cssSelector("#uspswd2")).sendKeys("testing06");
        driver.findElement(By.cssSelector("#usebillingaddress")).click();
        driver.findElement(By.cssSelector(".marg-top .success")).click();
        driver.findElement(By.cssSelector(".order-summary-standard")).click();
       // driver.findElement(By.cssSelector(".order-summary-nextday")).click();
        driver.findElement(By.cssSelector(".order-summary-storefree")).click();
        
	}

}
