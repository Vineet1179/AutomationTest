package tkmaxx;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class Trial {

	public static void main(String[] args) throws InterruptedException {
		System.setProperty("webdriver.gecko.driver", "C:/Users/User/Desktop/Automation/Driver/geckodriver/geckodriver.exe");
		WebDriver driver=new FirefoxDriver();
		driver.get("http://www.tkmaxx.com/");
		driver.manage().window().maximize();
		driver.findElement(By.xpath("//nav[@id='nav']//div[@class='topnav']//a[@id='mm_sub99']/..//a[contains(text(),'Home Clearance')]/../..//a[contains(text(),'Home Accessories')]")).click();
		

}
}