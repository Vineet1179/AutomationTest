package tkmaxx;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;

public class ExistingCustNextDayDelivery {

	public static void main(String[] args) {
		System.setProperty("webdriver.gecko.driver", "C:/Users/User/Desktop/Automation/Driver/geckodriver/geckodriver.exe");
		WebDriver driver=new FirefoxDriver();
		driver.get("http://www.tkmaxx.com/");
		driver.manage().window().maximize();
		driver.findElement(By.cssSelector(".header-row-two #q")).sendKeys("sunglasses");
        driver.findElement(By.cssSelector("#searchsubmit")).click();
        driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
        driver.findElement(By.cssSelector("#details-13201036 #comp-name13201036")).click();
        driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
        Select qty=new Select(driver.findElement(By.cssSelector("#qtybox .js-qty")));
        qty.selectByIndex(1);   
        driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
        driver.findElement(By.cssSelector(".js-addproduct")).click();
        driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
        driver.findElement(By.cssSelector(".notifyBox #checkout")).click();
        driver.findElement(By.cssSelector("#email")).sendKeys("test10089@gmail.com");
        driver.findElement(By.cssSelector("#password")).sendKeys("testing06");
        driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
        driver.findElement(By.cssSelector(".return-customer .js-trackoption")).click();
        driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
        driver.findElement(By.cssSelector(".order-summary-nextday")).click();
	}

}
