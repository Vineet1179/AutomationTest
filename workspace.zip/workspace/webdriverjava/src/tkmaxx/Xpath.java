package tkmaxx;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;

public class Xpath {

	public static void main(String[] args) throws InterruptedException {
		System.setProperty("webdriver.gecko.driver", "C:/Users/User/Desktop/Automation/Driver/geckodriver/geckodriver.exe");
		WebDriver driver=new FirefoxDriver();
		driver.get("http://www.tkmaxx.com/");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
		WebElement element= driver.findElement(By.xpath("//nav[@id='nav']//div[contains(@class,'topNavigationWrapper')]//a[@id='mm_sub99']"));
		Actions action=new Actions(driver);
		action.moveToElement(element).build().perform();
		//driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
		Thread.sleep(3000);
		//action.moveToElement(driver.findElement(By.xpath("//nav[@id='nav']//div[contains(@class,'topNavigationWrapper')]//a[@id='mm_sub99']/..//a[contains(text(),'Home Clearance')]/../..//a[contains(text(),'Home Accessories')]"))).click().build().perform();
		driver.findElement(By.xpath("//nav[@id='nav']//div[contains(@class,'topNavigationWrapper')]//a[@id='mm_sub99']/..//a[contains(text(),'Home Clearance')]/../..//a[contains(text(),'Home Accessories')]")).click();
		
		
		

	}

}
