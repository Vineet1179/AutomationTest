

public class Main_Class1 {

	public static void main(String[] args) {
		Audi_class audi=new Audi_class();
		audi.availability();
		audi.brakes();
		audi.fuel();
		audi.model();
		audi.name();
		audi.price();
		audi.steering();
		audi.wheels();
		
		
		Bmw_class bmw=new Bmw_class();
		bmw.name();
		bmw.availability();
		bmw.model();
		bmw.price();
		

	}

}
