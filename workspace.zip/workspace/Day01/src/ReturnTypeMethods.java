
public class ReturnTypeMethods {
	void sum()
	{
	int a=10, b=20,c;
	c=a+b;
	System.out.println("Sum="+c);
	
	}		

	int sub(int a,int b)
	{
		int c;
		c=a-b;
		return c;
		
		
	}
}


