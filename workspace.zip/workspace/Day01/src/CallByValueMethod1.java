
public class CallByValueMethod1 {
	int total,average;
		
	void sum(int a ,int b,int c,int d, int e,int f)
	{
		total=a+b+c+d+e+f;
		System.out.println("Sum="+total);
	}
	
	void avg()
	{
		average=total/6;
		System.out.println("Average result = "+average);
	}
	

}
