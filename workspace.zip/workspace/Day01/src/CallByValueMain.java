
public class CallByValueMain {

	public static void main(String[] args) {
		CallByValueMethods callbyvalueobject= new CallByValueMethods();
		callbyvalueobject.sum();
		callbyvalueobject.sub(20, 40);
		
		
		

	}

}
