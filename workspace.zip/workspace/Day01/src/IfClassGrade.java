  
public class IfClassGrade {

	public static void main(String[] args) {
		int s1=70,s2=45,s3=61,s4=76,s5=68,s6=84;
		double avg,total;
		
		total=s1+s2+s3+s4+s5+s6;
		avg=total/6;
		System.out.println("Average="+avg);
				
		if (avg>=0 && avg<=35 ) {
			System.out.println("The resulit is FAIL ");
			
		}
					
		
		else if(avg>=35 && avg<=50){
			System.out.println("The result is Third Class");
					
		}
	
		
		else if (avg>=50 && avg<=60){
			System.out.println("The result is Second Class");
		}
		
				
		else if (avg>=60 && avg<=75){
			System.out.println("The result is First Class");
		}
		else if(avg>=75 && avg<=100){
			System.out.println("The result is Distinction");
		}
	}
	
	

}
