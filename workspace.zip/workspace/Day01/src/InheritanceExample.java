
public class InheritanceExample {

	public static void main(String[] args) {
		
		Child c=new Child();
		c.p3();
		c.p4();
		c.p1();
		c.p2();

	}

}
