
public class IfTobaccoLimit {

	public static void main(String[] args) {
		int s1=18,s2=21,s3=25;
		if(s1>=0 && s2<=18){
			System.out.println("Selling of tobacco is illegal");
		}
		else if(s2>=18 && s3<=21){
			System.out.println("ID to be shown prior buying tobacco");
		}
		else if(s3>=21){
			System.out.println("Tobacco will be sold to that person");
		}
				
	}

}
