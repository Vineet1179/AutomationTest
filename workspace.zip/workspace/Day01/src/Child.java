
public class Child extends Father {
	void p3(){
		System.out.println("HI am from child class p3 method");
		
	}
	void p4(){
		System.out.println(" Hi am from child class p4 method");
		
	}

}
