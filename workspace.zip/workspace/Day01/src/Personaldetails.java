
public class Personaldetails {

	public static void main(String[] args) {
		String s_name="Vineet Muley";
		String qualification=" Navigator (Master II/2)";
		String address="21 Silverburn Road";
		String city="Glasgow";
		String country ="United Kingdom";
		System.out.println("My name is :"+s_name);
		System.out.println("I work as :"+qualification);
		System.out.println("My address is :"+address);
		System.out.println("The city I live in is :"+city);
		System.out.println("Name of the country is :"+country);
		

	}
 
}
  