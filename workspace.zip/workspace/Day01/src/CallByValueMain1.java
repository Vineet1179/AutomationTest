
public class CallByValueMain1 {

	public static void main(String[] args) {
		int a=10,b=20,c=30,d=40,e=50,f=60;
		CallByValueMethod1 callbyvalueobj= new CallByValueMethod1();
	    callbyvalueobj.sum(a, b, c, d, e, f);
	    callbyvalueobj.avg();
	    
	    

	}

}
