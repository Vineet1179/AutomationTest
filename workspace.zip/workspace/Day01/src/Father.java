
public class Father {
  void p1(){
	  System.out.println("Hi I am from father class p1 method");
	  
  }
  void p2(){
	  System.out.println("HI I am from father class p2 method");
	  
  }
 
  }

