
public class Conversions {

	public static void main(String[] args) {
		int a= 100,b=4,c;
		c=b*a;
		System.out.println(" 4 metres into centimetres = "+c);
		double x=100,y=5,z;
		 z=y/x;
		System.out.println("5 centimetres into metres="+z);
		
		
		

	}
	


	}
	
 

