
public class CallByValueMethods {

	void sum() {
		int a=20,b=40,c;
		c=a+b;
		System.out.println("Sum="+c);
						
	
	}
	 void sub(int a,int b){
		 int c;
		 c=a-b;
		 System.out.println("Sub="+c);
		 
		 
		 
	 }
	
}
