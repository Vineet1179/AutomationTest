
public class Addition {

	public static void main(String[] args) {
		int a= 20, b=40,c;
		c=a+b;
		System.out.println(c);
		
	}

}
