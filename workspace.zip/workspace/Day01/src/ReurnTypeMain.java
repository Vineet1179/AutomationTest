
public class ReurnTypeMain {

	public static void main(String[] args) {
		ReturnTypeMethods returntypeobj= new ReturnTypeMethods();
		int p;
		returntypeobj.sum();
		returntypeobj.sub(10, 20);
	p=returntypeobj.sub(10, 20);
	System.out.println("Sub="+p);
	

	}

}

