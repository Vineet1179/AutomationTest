package forLoop;

public class Decremental {

	public static void main(String[] args) {
		int i=10;
		for(i=10;i>0;i--){
			System.out.println("i= "+i);
		}

	}

}
