package forLoop;

public class ListEven_numbers {

	public static void main(String[] args) {
		int limit =50;
		System.out.println("The list of even number till "+limit);
		
		for(int i=1;i<=50;i++){
			if(i%2==0){
				System.out.print(i+ " ");
			}
			
		}

	}

}
