package forLoop;

public class Multiple_prints {

	public static void main(String[] args) {
		int i=1;
		for(i=1;i<=75;i++)
		{
			System.out.print("�");
		}
		
	}

}
