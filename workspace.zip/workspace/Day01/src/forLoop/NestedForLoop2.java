package forLoop;

public class NestedForLoop2 {

	public static void main(String[] args) {
		
		int i,j;
			
		for(i=0;i<=2;i++){
				for(j=0;j<=2;j++){
					System.out.print(i);
				}
				System.out.println("\n");
				
			}
			
			

			}


	}


