package forLoop;

public class ForArray {

	public static void main(String[] args) {
		int arr[]={2,11,45,9};
		
		for ( int i=0;i<=4;i++){
			System.out.println("arr[i]=" +i);
		}
				
	
	
	
	}

}
