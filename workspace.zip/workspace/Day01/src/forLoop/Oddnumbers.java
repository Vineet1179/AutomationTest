package forLoop;

public class Oddnumbers {

	public static void main(String[] args) {
		int limit=100;
		System.out.println("The odd numbers between 1 and "+limit);

		for(int i=1;i<=1000;i++){
			if (i%2==1){
				System.out.print(i+ " ");
			}
		}
	}

}
