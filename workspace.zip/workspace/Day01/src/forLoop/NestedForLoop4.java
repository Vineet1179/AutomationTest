package forLoop;

public class NestedForLoop4 {

	public static void main(String[] args) {
		int a,b;
		for(a=2;a>0;a--)
		{
			for(b=0;b<=2;b++)
			{
				System.out.print(a+""+b+" ");
			
			}
			System.out.println("\n");
			}

	}

}
