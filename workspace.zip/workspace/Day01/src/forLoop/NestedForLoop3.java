package forLoop;

public class NestedForLoop3 {

	public static void main(String[] args) {
		int i,j;
		for(i=0;i<=4;i++){
			for(j=0;j<=4;j++){
				System.out.print(i+""+j+" ");
			}
			System.out.println("\n");
		}

	}

}
