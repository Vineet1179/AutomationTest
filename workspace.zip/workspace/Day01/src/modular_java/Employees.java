package modular_java;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;

public class Employees {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
       WebDriver driver = new FirefoxDriver();
       driver.manage().window().maximize();
       driver.get("http://srssprojects.in/home.aspx");
       driver.findElement(By.id("txtuId")).sendKeys("Admin");
       driver.findElement(By.id("txtPword")).sendKeys("Admin");
       driver.findElement(By.id("login")).click();
       driver.findElement(By.xpath("//img[@src='images/emp_btn.jpg']")).click();
       driver.findElement(By.id("BtnNew")).click();
       driver.findElement(By.id("txtUname")).sendKeys("Vineet");
       driver.findElement(By.id("txtLpwd")).sendKeys("mindq");
       new Select(driver.findElement(By.id("lst_Roles"))).selectByVisibleText("manager");
       new Select(driver.findElement(By.id("lst_Branch"))).selectByVisibleText("78965");
       driver.findElement(By.id("BtnSubmit")).click();
       driver.switchTo().alert().accept();
       
	}

}
