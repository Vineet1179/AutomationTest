package modular_java;

public class Inputdata_class {

	
	
	public static String App_url= "http://srssprojects.in/home.aspx";
	public static String uid="Admin";
	public static String pwd="Admin";
	public static String brname= "Glasgow";
	public static String Address1="123 hope st";
	public static String Address2="hfie";
	public static String Address3="uegfu";
	public static String Area="Lark";
	public static String ZipCode="g6 2jj";
	public static String Country="UK";
	public static String State="England";
	public static String City="LONDON";
	public static String Submit="Submit";
	
	
	
	
	public static String EmployeeRoleName="Vineet";
	public static String LoginPasswprd= "mindq";
	public static String Role="manager";
	public static String Branch="78965";
	
	
	
	
}
	
	
