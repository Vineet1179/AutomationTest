package modular_java;

import java.io.File;
import java.text.DateFormat;
import java.text.SimpleDateFormat;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class Repo_class {
 public static WebDriver driver;
public static  void Application()
{
	 driver=new FirefoxDriver();
	 driver.get(Inputdata_class.App_url);
	driver.manage().window().maximize();
	
	 
}

public static void Admin_login()
{
	driver.findElement(Locators_class.A_username).sendKeys(Inputdata_class.uid);
	driver.findElement(Locators_class.A_password).sendKeys(Inputdata_class.pwd);
	driver.findElement(Locators_class.A_login).click();
	
}
   public static void Branch_creation1(){
	   driver.findElement(Locators_class.br_button).click();
	   driver.findElement(Locators_class.br_branchname).sendKeys("Glasgow");
	   driver.findElement(Locators_class.br_Address1).sendKeys("123 hope st");
	   driver.findElement(Locators_class.br_Address2).sendKeys("hfie");
	   driver.findElement(Locators_class.br_Address3).sendKeys("uegfu");
	   driver.findElement(Locators_class.br_Area).sendKeys("Lark");
	   driver.findElement(Locators_class.br_ZipCode).sendKeys("g6 2jj");
	   driver.findElement(Locators_class.br_Country).sendKeys("UK");
	   driver.findElement(Locators_class.br_State).sendKeys("England");
	   driver.findElement(Locators_class.br_City).sendKeys("LONDON");
	   driver.findElement(Locators_class.br_Submit).click();
	   
	   
	   
	
	   
	   
   }
 
 
 
 
 

public static void capture_screen(String imagename)
{
	try {
		DateFormat df=new SimpleDateFormat("DD_MM_YYYY HH_MM_SS");
		Date d=new Date();
		String time=df.format(d);
		File src=((TakeScreenshot)driver.getScreenshotAS(OutputType.FILE);
		FileUtils.copyFile(src, new File("Screen\\"+imagename+time+".png"));
		
		
		
	} catch (Exception e) {
		// TODO: handle exception
	}
}
