
package modular_java;

public class InputEmployess_data {

	

	public static String EmployerName="Vineet";
	public static String LoginPasswprd= "mindq";
	public static String Role="manager";
	public static String Branch="78965";
	
}
