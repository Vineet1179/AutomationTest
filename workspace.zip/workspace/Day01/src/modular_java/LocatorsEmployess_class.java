package modular_java;

import org.openqa.selenium.By;

public class LocatorsEmployess_class {
	
	public static By br_Employees=By.xpath("//img[@ src='images/emp_btn.jpg']");
	public static By br_EmployerName=By.id("txtUname");
	public static By br_LoginPassword=By.id("txtLpwd");
	public static By br_Role=By.id("lst_Roles");
	public static By br_Branch=By.id("lst_Branch");
	
	
	
}
