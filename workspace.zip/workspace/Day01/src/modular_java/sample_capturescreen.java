package modular_java;

import java.text.DateFormat;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;

public class sample_capturescreen {
try{
	
	DateFormat df=new SimpleDateFormat("DD_MM_YYYY HH_MM_SS");
	Date d=new Date();
	String time=df.format(d);
	File src=((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
	FileUtils.copyFile(src,new File("Screens\\"+imagename+time+".png"));
	
	
	
	catch (Exception e) {
}
	// TODO: handle exception
}
}
