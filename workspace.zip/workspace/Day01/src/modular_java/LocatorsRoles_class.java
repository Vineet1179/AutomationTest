package modular_java;

import org.openqa.selenium.By;

public class LocatorsRoles_class {

	
		public static By br_Roles= By.xpath("//img[@src='images/Roles_but.jpg']");
		public static By br_NewRole= By.id("btnRoles");
		public static By br_RoleName=By.id("txtRname");
		public static By br_RoleDesc=By.id("txtRDesc");
		public static By br_RoleType=By.id("lstRtypeN");
		

	}


