package modular_java;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class RepoEmp_class {
	
	public static WebDriver driver;
	public static void Application()
	{
		driver=new FirefoxDriver();
		driver.get(Inputdata_class.App_url);
		driver.manage().window().maximize();
		
	}
	public static void Employees()
	{
		driver.findElement(LocatorsEmployess_class.)
	driver.findElement(LocatorsEmployess_class.br_Employees).sendKeys("Vineet");
	}

}
