package modular_java;

import org.openqa.selenium.WebDriver;
import org.testng.Reporter;
import org.testng.annotations.Test;

public class modular_testable {
	public static WebDriver driver;
	
  @Test(priority=0)
  public void Application_launch() {
	  Repo_class.Application();
	  Reporter.log("Application is pass",true);
	  
  }
  @Test(priority=1)
  public void Admin(){
	  Repo_class.Admin_login();
	  Reporter.log("Admin login is pass",true);
	  
  }
  @Test(priority=2)
  public void Branch_creation(){
	  
  }
  
}

