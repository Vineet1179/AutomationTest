package modular_java;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;

public class Reporoles_class {
public static WebDriver driver;
public static void Application()
{
	driver=new FirefoxDriver();
	driver.get(Inputdata_class.App_url);
	driver.manage().window().maximize();
	
}
public static void Roles()
{
	driver.findElement(Locators_class.A_username).sendKeys(Inputdata_class.uid);
	driver.findElement(Locators_class.A_password).sendKeys(Inputdata_class.pwd);
	new Select(driver.findElement(By.id("lstRtypeN"))).selectByVisibleText("E");
	
}
}
