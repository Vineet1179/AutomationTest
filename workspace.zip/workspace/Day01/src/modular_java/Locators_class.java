package modular_java;

import org.openqa.selenium.By;

public class Locators_class {

	
	//Admin_login
	public static By A_username=By.id("txtuId");
	public static By A_password=By.id("txtPword");
	public static By A_login=By.id("login");
	
	public static By br_button=By.xpath("//img[@src='images/emp_btn.jpg']");
	public static By Br_newbranchbutton= By.id("BtnNewBR");
	public static By br_branchname=By.id("txtbName");
	public static By br_Address1=By.id("txtAdd1");
	public static By br_Address2=By.id("Txtadd2");
	public static By br_Address3=By.id("txtadd3");
	public static By br_Area=By.id("txtArea");
	public static By br_ZipCode=By.id("txtZip");
	public static By br_Country=By.id("lst_counrtyU");
	public static By br_State=By.id("lst_stateI");
	public static By br_City=By.id("lst_cityI");
	public static By br_Submit=By.id("btn_insert");
	
	
	
	
	
	
	
	
	
	
}

