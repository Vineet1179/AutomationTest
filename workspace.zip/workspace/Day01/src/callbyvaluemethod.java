
public class callbyvaluemethod {
	int c;
	void sum(int a,int b,int d,int f,int g, int j,int k )
	{
		c=a+b+d+f+g+j+k;
		System.out.println("Sum="+c);
		
	}
	void mul(int a,int b,int d,int f,int g,int j,int k)
	{
		c=a*b*d*f*g*j*k;
		System.out.println("Multiplication ="+c);
		
	}
}
