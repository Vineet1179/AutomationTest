
public class Bmw_class {
	void name(){
		System.out.println("Car name is BMW X4");
	}
	void model(){
		System.out.println("model is X4");
	}
	void price(){
		System.out.println("price is �12,000");
	}
	void availability (){
		System.out.println("Car needs to be booked 1 month in advance");
	}
	
	}

