
public class Audi_class {
void name(){
	System.out.println("car name is Audi A7");
}
		void model(){
	System.out.println("It has alloy wheels");
		}
		void brakes(){
			System.out.println("It has disc brakes");
		}
	void fuel(){
		System.out.println("It runs on Petrol");
	}
	void steering(){
		System.out.println("Car has power steering");
	}
	void wheels(){
		System.out.println("it has alloy wheels");
	}
	void price(){
		System.out.println("Price is �34,000");
	}
	void availability(){
		System.out.println(" Avaliable in 2 weeks time");

		
			
		}
	
}

