
public class ReturnTypeExample {
	
		
int a=10,b=20,c;
int sum(){
	int a=10,b=20,c;
	c=a+b;
	return c;
	
	
}
int mul(){
int a=10,b=30,c;
c=a*b;
return c;


 



}
}
