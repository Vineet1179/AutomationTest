
public class IfEvenOdd {



			public static void main(String[] args) {
				int a=4,b=3;
				if (a/2==2) {
					System.out.println("The grade is a even number");
					
				} else {
					System.out.println("The grade is a odd number ");

				}
				if (b%2==1) {
					System.out.println("The grade is a odd number");
					
				} else if (b/2==2){
					System.out.println("The grade is a even number ");

				}
			}

		


		
		

		}
	

