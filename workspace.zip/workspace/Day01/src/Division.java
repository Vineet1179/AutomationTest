
public class Division {

	public static void main(String[] args) {
		int a= 450,b=5,c;
		c=a/b;
		System.out.println(c);
		

	}

}
