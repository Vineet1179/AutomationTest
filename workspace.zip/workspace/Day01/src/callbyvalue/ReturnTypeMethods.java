package callbyvalue;

public class ReturnTypeMethods {
	int x= 30, y=40,z;
	int add()
	{
		z=x+y;
			//System.out.println("Sum="+z);
		return z;
		
	}

}
