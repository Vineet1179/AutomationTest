
public class MainClass {

	public static void main(String[] args) {
		int p;
		ReturnTypeExample returntypeexample= new ReturnTypeExample();
		p=returntypeexample.sum()+returntypeexample.mul();
		System.out.println();
	
		

	}

}
