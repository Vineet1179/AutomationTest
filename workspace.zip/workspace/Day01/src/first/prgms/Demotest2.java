package first.prgms;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class Demotest2 {

	public static void main(String[] args) {
		WebDriver driver= new FirefoxDriver();
		driver.navigate().to("http://google.com");
		driver.manage().window().maximize();
		driver.navigate().refresh();
		driver.navigate().to("http://facebook.com");
		driver.navigate().back();
		driver.navigate().forward();
		driver.close();
		
		
		

	}

}
