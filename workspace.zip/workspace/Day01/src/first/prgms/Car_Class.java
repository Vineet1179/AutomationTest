package first.prgms;

public class Car_Class  {
	 void name(){
		System.out.println("Name of the car is BMW");
	}
	void seating(){
		System.out.println("Car has 4 seats");
	}
	void steering(){
		System.out.println("Care has power steering");
	}
	void wheels(){
		System.out.println("car has alloy wheels");
	}
		
	void brakes(){
		System.out.println("car has disc brakes");
		
	}
	void fuel(){
		System.out.println("Its runs on Diesel");
	}
	
		
	

	

	}


