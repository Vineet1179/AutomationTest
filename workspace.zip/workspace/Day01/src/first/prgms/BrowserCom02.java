package first.prgms;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class BrowserCom02 {

	public static void main(String[] args) {
		WebDriver driver= new FirefoxDriver();
		driver.navigate().to("http://gmail.com");
		driver.manage().window().maximize();
		driver.get("http://google.co.in");
		driver.navigate().refresh();
		driver.navigate().back();
		driver.navigate().forward();
		driver.quit();
		
		

	}

}
