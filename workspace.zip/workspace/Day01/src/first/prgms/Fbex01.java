package first.prgms;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class Fbex01 {

	public static void main(String[] args) {

		WebDriver driver= new FirefoxDriver();
		driver.get("http://facebook.com");
		driver.manage().window().maximize();
		driver.findElement(By.id("email")).sendKeys("vineet");
		driver.findElement(By.id("pass")).sendKeys("mercury");
		driver.findElement(By.id("loginbutton")).click();
		
		
		
		
	}

}
