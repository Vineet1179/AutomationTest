package first.prgms;

import java.util.Scanner;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class InvokeBr {

	public static void main(String[] args) {
		
		System.out.println("insightq");
		System.out.print("bfjdsbf");
		System.out.println("nnfpo");
		System.out.println("heifef");
		
		
		System.out.println("enter name");
		Scanner sc= new Scanner(System.in);
		String cname= sc.next();
		System.out.println("entered value is:"+cname);
		
		String mystatus= "vineet";
		 System.out.println(mystatus);
		 
		 
		
		
		
		
		
		


	}

}
