package first.prgms;

import java.util.Scanner;

public class FirstPrg {

	public static void main(String[] args) {
		String mystatus= "Vineet";
		System.out.println(mystatus);
		
		
		
		

	}

}
