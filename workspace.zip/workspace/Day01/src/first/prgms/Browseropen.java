package first.prgms;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class Browseropen {

	public static void main(String[] args) {
		WebDriver driver= new FirefoxDriver();
		driver.get("http://facebook.com");
		
		String pgUrl= driver.getTitle();
		System.out.println(pgUrl);
		
		String pgTitle= driver.getTitle();
		System.out.println(pgTitle);
		
		String pgSource= driver.getPageSource();
		System.out.println(pgSource);
		
		
		
		

		
		
			

	}

}
