package first.prgms;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class ComExam1 {

	public static void main(String[] args) {
		WebDriver driver= new FirefoxDriver();
		driver.get("http://newtours.demoaut.com");
		String pgUrl= driver.getCurrentUrl();
		System.out.println("pgUrl is :" +pgUrl);
		String getTitle= driver.getTitle();
		System.out.println("current page title is:"+getTitle);
		String pgSource= driver.getPageSource();
		System.out.println("page Source code is:"+pgSource);
		driver.close();
		
		
		
		
		

	}

}
