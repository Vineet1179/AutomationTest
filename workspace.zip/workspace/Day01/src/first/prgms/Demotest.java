package first.prgms;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class Demotest {

	public static void main(String[] args) {
		WebDriver driver= new FirefoxDriver();
		driver.navigate().to ("http://www.facebook.com");
			driver.manage().window().maximize();
		driver.navigate().refresh();
		driver.navigate().to ("http://www.google.com");
			driver.navigate().back();
		driver.navigate().forward();
		driver.close();
		
		

	}

}
