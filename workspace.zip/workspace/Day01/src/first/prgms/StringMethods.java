package first.prgms;

public class StringMethods {

	public static void main(String[] args) {
		
		String cname= "MindqSystems";
		System.out.println(cname.length());
		System.out.println(cname.charAt(4));
		System.out.println(cname.indexOf("q"));
		System.out.println(cname.toUpperCase());
		System.out.println(cname.toLowerCase());
		System.out.println(cname.equals("Mindq"));
		System.out.println(cname.equalsIgnoreCase("MINDQSYSTEMS"));
		System.out.println(cname.substring(0,5));
		System.out.println(cname.replace("S", "@"));
		String x=" Mindq ";
		System.out.println(x.length());
		System.out.println(x.trim().length());
		String y="Gmri Gdns";
		System.out.println(y.trim().length());
		
		
		
		
		
		
		
		
		
		
		
		
				
	}

}
