package first.prgms;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class Seleniumcommands {

	public static void main(String[] args) throws InterruptedException {
		WebDriver driver= new FirefoxDriver();
		driver.manage().window().maximize();
		driver.get("http://gmail.com");
		// to get page title
		String pgTitle= driver.getTitle();
		System.out.println("Tile of page1="+pgTitle);
		Thread.sleep(3000);
		driver.navigate().to("http://youtube.com");
		pgTitle= getTitle();
		System.out.println("Title of Page 2="+pgTitle);
		driver.navigate().back();
		pgTitle= getTitle();
		System.out.println("Title of page3="+pgTitle);
		Thread.sleep(3000);
		driver.navigate().refresh();
		driver.navigate().forward();
		pgTitle= getTitle();
		System.out.println("Title of page4="+pgTitle);
		Thread.sleep(3000);
		driver.close();
		
		
		

	}

	private static String getTitle() {
		// TODO Auto-generated method stub
		return null;
	}

}
