package first.prgms;

public class Main_Class {

	public static void main(String[] args) {
	Car_Class  car=new Car_Class();
	car.brakes();
	car.fuel();
	car.seating();
	car.steering();
	car.wheels();
	car.name();
	
	

	}

}
