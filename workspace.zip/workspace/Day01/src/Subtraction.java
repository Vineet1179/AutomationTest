
public class Subtraction {

	public static void main(String[] args) {
		int a= 500,b=450,c;
		c=a-b;
		System.out.println("The answer is ="+c);
		

	}

}
