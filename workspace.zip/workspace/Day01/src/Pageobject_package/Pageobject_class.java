package Pageobject_package;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import modular_java.LocatorsEmployess_class;
import modular_java.LocatorsRoles_class;
import modular_java.LocatorsEmployess_class;
import modular_java.Locators_class;

public class Pageobject_class {
//Admin_username
	public static WebElement username(WebDriver driver)
	{
		return driver.findElement(Locators_class.A_username);
		
	}
//Admin_password
	public static WebElement  password(WebDriver driver)
	{
		return driver.findElement(Locators_class.A_password);
		
	}
	//Admin_login
	public static WebElement login_button(WebDriver driver)
	{
		return driver.findElement(Locators_class.A_login);
		
	}
	//Branch_Name
	public static WebElement Br_Branchname(WebDriver driver)
	{
		return driver.findElement(Locators_class.br_branchname);
		
	}
	//Branch_Address1
	public static WebElement Br_Address1(WebDriver driver)
	{
		return driver.findElement(Locators_class.br_Address1);
	}
	//Branch_Address2
	public static WebElement Br_Address2(WebDriver driver)
	{
		return driver.findElement(Locators_class.br_Address2);
	}
	//Branch_Address3
	public static WebElement Br_Address3(WebDriver driver )
	{
		return driver.findElement(Locators_class.br_Address3);
	}
	//Branch_Area
	public static WebElement Br_Area(WebDriver driver)
	{
		return driver.findElement(Locators_class.br_Area);
	}
	//Branch_Zipcode
	public static WebElement Br_ZipCode(WebDriver driver)
	{
		return driver.findElement(Locators_class.br_ZipCode);
	}
	//Branch_country
	public static WebElement Br_Country(WebDriver driver)
	{
		return driver.findElement(Locators_class.br_Country);
	}
	//Branch_State
	public static WebElement Br_State(WebDriver driver)
	{
		return driver.findElement(Locators_class.br_State);
	}
	//Branch_City
	public static WebElement Br_City(WebDriver driver)
	{
		return driver.findElement(Locators_class.br_City);

	}

   //Employer_Name
public static WebElement Br_Employername(WebDriver driver)
{
	return driver.findElement(LocatorsEmployess_class.br_Employees);
}
//Employer_Loginpassword
 public static WebElement Br_Loginpassword(WebDriver driver)
 {
	 return driver.findElement(LocatorsEmployess_class.br_LoginPassword);
 }
	 //Empolyer_Role
	 public static WebElement br_Role(WebDriver driver)
	 {
		 return driver.findElement(LocatorsEmployess_class.br_Role);
	 }
	 //Role_Name
	 public static WebElement br_RoleName(WebDriver driver)
	
	 {
	   return driver.findElement(LocatorsRoles_class.br_RoleName)	;
	 }
	 //Role_Desc
	  public static WebElement br_RoleDesc(WebDriver driver)
	  {
		  return driver.findElement(LocatorsRoles_class.br_RoleDesc);
	  }
	  //Role_Type
	  public static WebElement br_RoleType(WebDriver driver)
	  {
		  return driver.findElement(LocatorsRoles_class.br_RoleType);
		  
	  
	 }
}
    