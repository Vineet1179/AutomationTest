package Pageobject_package;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.Test;

import modular_java.InputEmployess_data;
import modular_java.Inputdata_class;


public class Pageobject_testable {
	public static WebDriver driver;
  @Test(priority=0)
  public void f() {
	  
	  driver=new FirefoxDriver();
	  driver.get(Inputdata_class.App_url);
	  driver.manage().window().maximize();
  }
  @Test(priority=1)
  public void Admin_Login()
  {
 Pageobject_class.username(driver).sendKeys(Inputdata_class.uid);	
 Pageobject_class.password(driver).sendKeys(Inputdata_class.pwd);
 Pageobject_class.login_button(driver).click();
  }
  
 @Test(priority=2)
  
  public void Branch_Name(){
  Pageobject_class.Br_Branchname(driver).sendKeys(Inputdata_class.brname);
  Pageobject_class.Br_Address1(driver).sendKeys(Inputdata_class.Address1);
  Pageobject_class.Br_Address2(driver).sendKeys(Inputdata_class.Address2);
  Pageobject_class.Br_Address3(driver).sendKeys(Inputdata_class.Address3);
  Pageobject_class.Br_Area(driver).sendKeys(Inputdata_class.Area);
  Pageobject_class.Br_ZipCode(driver).sendKeys(Inputdata_class.ZipCode);
  Pageobject_class.Br_Country(driver).sendKeys(Inputdata_class.Country);
  Pageobject_class.Br_State(driver).sendKeys(Inputdata_class.State);
  Pageobject_class.Br_City(driver).sendKeys(Inputdata_class.City);
  
 }

 @Test(priority=3)
 public void Role(){
	 
	 Pageobject_class.br_RoleName(driver).sendKeys(input);
	 Pageobject_class.br_RoleDesc(driver).sendKeys(Inputdata_class.);
	 Pageobject_class.br_RoleType(driver).sendKeys(Inputdata_class.);
 }
 
 @Test(priority=4)
 public void  Employee(){
	 Pageobject_class.Br_Employername(driver).sendKeys(InputEmployess_data.EmployerName);
	 Pageobject_class.Br_Loginpassword(driver).sendKeys(InputEmployess_data.LoginPasswprd);
     Pageobject_class.br_Role(driver).sendKeys(InputEmployess_data.Role);
     Pageobject_class.Br_Branchname(driver).sendKeys(InputEmployess_data.Branch);
     
  
	 
	 
 
 
  
  
 }
 }
  
  


