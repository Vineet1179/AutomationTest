package inheritance;

public class OverLoadingExample {

	public static void main(String[] args) {
		BMWCar bmw=new BMWCar();
		bmw.brakes();
		bmw.features();
		bmw.price();
		bmw.seating();
		bmw.tyres();
		bmw.steering();
		
		BMW7Series bmw7s=new BMW7Series();
		bmw7s.model();
		bmw7s.brakes();
		bmw7s.features();
		bmw7s.seating();
		bmw7s.steering();
		bmw.price();
		bmw.tyres();
		
		CarInterface cari=new BMWCar();
		cari.brakes();
		cari.seating();
		cari.steering();
		cari.tyres();
		
		AudiCar audi=new AudiCar();
		audi.brakes();
		audi.name();
		audi.tyres();
		audi.price();
		audi.seating();
		audi.steering();
		
		
		CarInterface acari=new AudiCar();
		acari.brakes();
		acari.seating();
		acari.steering();
		acari.tyres();
		
		

	}

}
