package inheritance;

public class BMW7Series extends BMWCar {
 void model(){
	 System.out.println("This is BMW 7 series");
	 
 }
 
}
