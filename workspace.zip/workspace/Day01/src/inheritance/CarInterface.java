package inheritance;

public interface CarInterface {
	
	void tyres();
	void seating();
	void steering();
	void brakes();
	   

}
