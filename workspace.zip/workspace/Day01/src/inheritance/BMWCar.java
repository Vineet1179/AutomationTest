package inheritance;

public class BMWCar implements CarInterface {
	
	
	
	
	void name(){
		System.out.println( "This is a BMW car");
		
	}
    
	void price(){
		System.out.println(" The price of the car is �40000");
		
	}
	void features(){
		System.out.println("The car has a twin V8 engine");
	}

	
	public void tyres() {
			System.out.println("The car has 4 BMW tubeless tyres");
			
	}

	
	public void seating() {
		System.out.println("This car has leather seats");
		
	}

	
	public void steering() {
		System.out.println("This car has power steering");
		
		
	}

	
	public void brakes() {
		System.out.println("This car has ABS brakes");
		
	}
	
	
}
