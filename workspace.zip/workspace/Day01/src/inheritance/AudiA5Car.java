package inheritance;

public class AudiA5Car extends AudiCar {
	void name(){
		System.out.println("This is a Audi A5 car");
		
	}
    void price(){
    	System.out.println("The price of this car is �34000");
    	
    }
    void features(){
    	System.out.println("This car has a multu link suspension");
    }
    void engine(){
    	System.out.println("The car has a modified twin v8 engine");
    }
}
