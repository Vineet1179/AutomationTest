package inheritance;

public class AudiA4Car extends AudiCar {
      void name(){
    	  System.out.println("This is a Audi A4 car ");
      }
      void price(){
    	  System.out.println("The price is �26000");
    	  
      }
      void features(){
    	  System.out.println("The car has a quottro all wheel drive system");
      }
      void sound(){
    	  System.out.println("The car is fitted with Bang and Olufsen 3D surround system");
      }

}
