package inheritance;

public class Car {
	void tyres(){
		System.out.println("This car has 4  tyres ");
		
	}
   void seat(){
	   System.out.println("This car has 5  seats");
	   
   }

   
}

