package inheritance;

public class RollsRoyceCar extends Car{
	
	void name(){
		System.out.println("This is a RollsRoyce Phantom car");
	}
	 
	void price(){
	 System.out.println("The price is �400000");
	}

	  void features(){
		  System.out.println("The car has Unique aluminium suspension");
	  }
}
