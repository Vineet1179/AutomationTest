package inheritance;

public class AudiCar implements  CarInterface{
  void name(){
	  System.out.println("This is a Audicar");
	  
  }
  
  void price(){
	  System.out.println("The car price is �30000");
	  
  }


public void tyres() {
	System.out.println("This car has 4  Audi anti skid snow tyres");
}


public void seating() {
	System.out.println("This car has Audi fire resistant seats");
	
}


public void steering() {
	System.out.println("This car has Audi power steering");
	
}


public void brakes() {
	System.out.println("This car has Audi ABS brakes");
	
	
}

}

