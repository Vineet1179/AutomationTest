package inheritance;

public class InheritanceAudi_Car {

	public static void main(String[] args) {
		AudiA4Car audi4=new AudiA4Car();
		audi4.name();
		audi4.seating();
		audi4.tyres();
		audi4.price();
		audi4.features();
		audi4.sound();
		
		AudiA5Car audi5 =new AudiA5Car();
		audi5.name();
		audi5.tyres();
		audi5.seating();
		audi5.price();
		audi5.features();
		audi5.engine();
		
		AudiQ7Car q7=new AudiQ7Car();
		q7.name();
		q7.seating();
		q7.tyres();
		q7.price();
		q7.features();
		q7.color();
		

	}

}
