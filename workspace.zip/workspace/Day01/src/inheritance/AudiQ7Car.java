package inheritance;

public class AudiQ7Car extends AudiCar{
	void name(){
		System.out.println("The care is Audi Q7");
		
	}
  
	void price(){
		System.out.println("The price os this car is �65000");
		
	}
	void features(){
		System.out.println("The car has a hill descent control");
		
		
	}
	void color(){
		System.out.println("The metallic colors of the car cost more than other cars");
	}
}
