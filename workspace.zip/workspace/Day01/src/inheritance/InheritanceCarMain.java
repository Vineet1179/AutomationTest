package inheritance;

public class InheritanceCarMain {

	public static void main(String[] args) {
		AudiCar audicar=new AudiCar();
		audicar.name();
		audicar.seating();
		audicar.price();
		audicar.tyres();
		
		BMWCar bmw=new BMWCar();
		bmw.name();
		bmw.seating();
		bmw.price();
		bmw.tyres();
		bmw.features();
		
		RollsRoyceCar rolls=new RollsRoyceCar();
		rolls.name();
		rolls.seat();
		rolls.tyres();
		rolls.price();
		rolls.features();
		
		

	}

}
