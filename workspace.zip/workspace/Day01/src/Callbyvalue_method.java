
public class Callbyvalue_method {

	public static void main(String[] args)
	{
		int x=10,y=40,d=20,f=50,g=70,j=60,k=70;
		callbyvaluemethod callbyvalueobj=new callbyvaluemethod();
		callbyvalueobj.sum(x, y, d, f, g, j, k);
		callbyvalueobj.mul(x, y, d, f, g, j, k);
		
		
	
		
		
		
				

	}

}
