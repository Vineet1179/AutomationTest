package com.lib;

import org.openqa.selenium.By;

import com.tkmaxx.PageObjectBaseClass;

public class BusinessLib extends PageObjectBaseClass{
	
	public void clickOnSearchButton(){
		
		 
		  driver.findElement(By.cssSelector("#searchsubmit")).click();
		  
	}
	
	public void enterTheSearchValue(){
		
		 driver.findElement(By.cssSelector("input[type='search']")).clear();
		  driver.findElement(By.cssSelector("input[type='search']")).sendKeys("sunglasses");
	}
	
	public void checkOutButton(){
		driver.findElement(By.cssSelector(".notifyBox #checkout")).click();
		
	}
	
	public void selectGuestCheckoutOptionINCheckoutPage(){
		driver.findElement(By.cssSelector(".box .js-trackoption")).click();
	}

}
