package com.lib;

import java.util.concurrent.TimeUnit;

import com.tkmaxx.PageObjectBaseClass;
public class SystemLib extends PageObjectBaseClass{
	
	public void waitForPageLoad(){
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	}
	
	public void  waitForMilliseconds(){
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
