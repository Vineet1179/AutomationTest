package com.pages;

public class BasketPage {

}
