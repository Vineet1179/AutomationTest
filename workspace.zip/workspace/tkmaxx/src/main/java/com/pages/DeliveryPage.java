package com.pages;

import org.openqa.selenium.By;

import com.tkmaxx.PageObjectBaseClass;

public class DeliveryPage extends PageObjectBaseClass{
	
	public void deliveryOptions(){
	
		 driver.findElement(By.cssSelector(".order-summary-nextday")).click();
	}

	public void deliveryOptionstd(){
		driver.findElement(By.cssSelector(".order-summary-standard")).click();
	}
	
	public void deliveryOptionsClickCollect(){
		
		 driver.findElement(By.cssSelector(".order-summary-storefree")).click();

	}
}
