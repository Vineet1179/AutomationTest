package com.pages;

import org.openqa.selenium.By;

import com.tkmaxx.PageObjectBaseClass;

public class SearchResultsPage extends PageObjectBaseClass {
	
	
	public void searchAProduct(){
		driver.findElement(By.cssSelector(".header-row-two #q")).sendKeys("sunglasses");
		
	}

}
