package com.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.Select;

import com.tkmaxx.PageObjectBaseClass;

public class ProductDetailsPage extends PageObjectBaseClass {
	
	public void productDetail(){
		driver.findElement(By.cssSelector("#details-13201036 #comp-name13201036")).click();
	}

	public void selectQuantity(){
		Select qty=new Select(driver.findElement(By.cssSelector("#qtybox .js-qty")));
		qty.selectByIndex(1);   
	}
	
	public void clickOnaddProductToBasketButton(){
		driver.findElement(By.cssSelector(".js-addproduct")).click();
		
	}
	
}


