package com.pages;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.Select;

import com.tkmaxx.PageObjectBaseClass;

public class BillingPage extends PageObjectBaseClass{

	public void enterAllBillingDetails(){
		
		Select title=new Select(driver.findElement(By.cssSelector("#billingaddressadd #title")));
		title.selectByVisibleText("Mr");
		driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
		driver.findElement(By.cssSelector(".row #fname")).sendKeys("Bruce");
		driver.findElement(By.cssSelector(".row #lname")).sendKeys("Wayne");
		driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
		Select gender=new Select(driver.findElement(By.cssSelector(".form-select")));
		gender.selectByVisibleText("Male");
		Select day=new Select(driver.findElement(By.cssSelector("#billingaddressadd .form-half-input")));
		day.selectByVisibleText("1");
		driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
		Select month=new Select(driver.findElement(By.cssSelector("select[name='remmonth1']")));
		month.selectByVisibleText("April");
		driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
		Select year=new Select(driver.findElement(By.cssSelector("select[name='remyear']")));
		year.selectByVisibleText("1972");
		driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
		Select cntry=new Select(driver.findElement(By.cssSelector("#cntrylist")));
		cntry.selectByVisibleText("United Kingdom");
		driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
		driver.findElement(By.cssSelector("#zipc")).sendKeys("G53 7PH");
		driver.findElement(By.cssSelector("#js-lookup-submit-btn")).click();
		Select add= new Select(driver.findElement(By.cssSelector("#js-lookupselect")));
		add.selectByIndex(4);
		driver.findElement(By.cssSelector("#phone")).sendKeys("07891379993");
		driver.findElement(By.cssSelector("#usemail")).sendKeys("test137790@gmail.com");
		driver.findElement(By.cssSelector("#uspswd")).sendKeys("testing05");
		driver.findElement(By.cssSelector("#uspswd2")).sendKeys("testing05");
		driver.findElement(By.cssSelector("#usebillingaddress")).click();
		driver.findElement(By.cssSelector(".marg-top .success")).click();
		    
	

		
	}
	
	public void enterBillingAddManually(){
		  Select title=new Select(driver.findElement(By.cssSelector("#billingaddressadd #title")));
		    title.selectByVisibleText("Mr");
		    driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
		    driver.findElement(By.cssSelector(".row #fname")).sendKeys("Bruce");
		    driver.findElement(By.cssSelector(".row #lname")).sendKeys("Wayne");
		    driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
		    Select gender=new Select(driver.findElement(By.cssSelector(".form-select")));
		    gender.selectByVisibleText("Male");
		    Select day=new Select(driver.findElement(By.cssSelector("#billingaddressadd .form-half-input")));
		    day.selectByVisibleText("1");
		    driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
		    Select month=new Select(driver.findElement(By.cssSelector("select[name='remmonth1']")));
		    month.selectByVisibleText("April");
		    driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
		    Select year=new Select(driver.findElement(By.cssSelector("select[name='remyear']")));
		    year.selectByVisibleText("1972");
		    driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
		    Select cntry=new Select(driver.findElement(By.cssSelector("#cntrylist")));
		    cntry.selectByVisibleText("United Kingdom");
		    driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
		    driver.findElement(By.cssSelector("#js-manual-reset-btn")).click();
		    driver.findElement(By.cssSelector("#num")).sendKeys("23");
		    driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
		    driver.findElement(By.cssSelector("#addr1")).sendKeys("Gamrie Gardens");
		    driver.findElement(By.cssSelector("#addr2")).sendKeys("Cul De Sac");
		    driver.findElement(By.cssSelector("#city")).sendKeys("Glasgow");
		    driver.findElement(By.cssSelector("#statetext")).sendKeys("UK");
		    driver.findElement(By.cssSelector("#zipc")).sendKeys("G53 7PH");
		    driver.findElement(By.cssSelector("#phone")).sendKeys("07841378993");
		    driver.findElement(By.cssSelector("#usemail")).sendKeys("test12890@gmail.com");
		    driver.findElement(By.cssSelector("#uspswd")).sendKeys("testing04");
		    driver.findElement(By.cssSelector("#uspswd2")).sendKeys("testing04");
		    driver.findElement(By.cssSelector("#usebillingaddress")).click();
		    driver.findElement(By.cssSelector(".marg-top .success")).click();
	}
	
	public void newCustomer(){
		 driver.findElement(By.cssSelector(".new-customer .button")).click();
	}
	
	public void newCustomerBillingManual(){
		  driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
		     driver.findElement(By.cssSelector(".row #fname")).sendKeys("Thomas");
		     driver.findElement(By.cssSelector(".row #lname")).sendKeys("Smith");
		     driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
		     Select gender=new Select(driver.findElement(By.cssSelector(".form-select")));
		     gender.selectByVisibleText("Male");
		     Select day=new Select(driver.findElement(By.cssSelector("#billingaddressadd .form-half-input")));
		     day.selectByVisibleText("4");
		     driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
		     Select month=new Select(driver.findElement(By.cssSelector("select[name='remmonth1']")));
		     month.selectByVisibleText("April");
		     driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
		     Select year=new Select(driver.findElement(By.cssSelector("select[name='remyear']")));
		     year.selectByVisibleText("1974");
		     driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
		     Select cntry=new Select(driver.findElement(By.cssSelector("#cntrylist")));
		     cntry.selectByVisibleText("United Kingdom");
		     driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
		     driver.findElement(By.cssSelector("#js-manual-reset-btn")).click();
		     driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
		     driver.findElement(By.cssSelector("#num")).sendKeys("27");
		     driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
		     driver.findElement(By.cssSelector("#addr1")).sendKeys("Gamrie Gardens");
		     driver.findElement(By.cssSelector("#addr2")).sendKeys("Main door");
		     driver.findElement(By.cssSelector("#city")).sendKeys("Glasgow");
		     driver.findElement(By.cssSelector("#statetext")).sendKeys("United Kingdom");
		     driver.findElement(By.cssSelector("#zipc")).sendKeys("G53 7PH");
		     driver.findElement(By.cssSelector("#phone")).sendKeys("07871378993");
		     driver.findElement(By.cssSelector("#usemail")).sendKeys("test10090@gmail.com");
		     driver.findElement(By.cssSelector("#uspswd")).sendKeys("testing06");
		     driver.findElement(By.cssSelector("#uspswd2")).sendKeys("testing06");
		     driver.findElement(By.cssSelector("#usebillingaddress")).click();
		     driver.findElement(By.cssSelector(".marg-top .success")).click();
		     
	}
	
	public void newCustStdFindAdd1(){
		
		driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
	     driver.findElement(By.cssSelector(".row #fname")).sendKeys("Joe");
	     driver.findElement(By.cssSelector(".row #lname")).sendKeys("Smith");
	     driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
	     Select gender=new Select(driver.findElement(By.cssSelector(".form-select")));
	     gender.selectByVisibleText("Male");
	     Select day=new Select(driver.findElement(By.cssSelector("#billingaddressadd .form-half-input")));
	     day.selectByVisibleText("1");
	     driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
	     Select month=new Select(driver.findElement(By.cssSelector("select[name='remmonth1']")));
	     month.selectByVisibleText("April");
	     driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
	     Select year=new Select(driver.findElement(By.cssSelector("select[name='remyear']")));
	     year.selectByVisibleText("1972");
	     driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
	     Select cntry=new Select(driver.findElement(By.cssSelector("#cntrylist")));
	     cntry.selectByVisibleText("United Kingdom");
	     driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
	     driver.findElement(By.cssSelector("#zipc")).sendKeys("G53 7PH");
	     driver.findElement(By.cssSelector("#js-lookup-submit-btn")).click();
	     Select add= new Select(driver.findElement(By.cssSelector("#js-lookupselect")));
	     add.selectByIndex(8);
	     driver.findElement(By.cssSelector("#phone")).sendKeys("07891378993");
	     driver.findElement(By.cssSelector("#usemail")).sendKeys("test13000@gmail.com");
	     driver.findElement(By.cssSelector("#uspswd")).sendKeys("testing05");
	     driver.findElement(By.cssSelector("#uspswd2")).sendKeys("testing05");
	     driver.findElement(By.cssSelector("#usebillingaddress")).click();
	     driver.findElement(By.cssSelector(".marg-top .success")).click();
		
	}
	
	public void newCustNextDayManualAdd2(){
		driver.findElement(By.cssSelector(".row #fname")).sendKeys("Gary");
	    driver.findElement(By.cssSelector(".row #lname")).sendKeys("Walsh");
	    driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
	    Select gender=new Select(driver.findElement(By.cssSelector(".form-select")));
	    gender.selectByVisibleText("Male");
	    Select day=new Select(driver.findElement(By.cssSelector("#billingaddressadd .form-half-input")));
	    day.selectByVisibleText("4");
	    driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
	    Select month=new Select(driver.findElement(By.cssSelector("select[name='remmonth1']")));
	    month.selectByVisibleText("April");
	    driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
	    Select year=new Select(driver.findElement(By.cssSelector("select[name='remyear']")));
	    year.selectByVisibleText("1974");
	    driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
	    Select cntry=new Select(driver.findElement(By.cssSelector("#cntrylist")));
	    cntry.selectByVisibleText("United Kingdom");
	    driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
	    driver.findElement(By.cssSelector("#js-manual-reset-btn")).click();
	    driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
	    driver.findElement(By.cssSelector("#num")).sendKeys("21");
	    driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
	    driver.findElement(By.cssSelector("#addr1")).sendKeys("Gamrie Gardens");
	    driver.findElement(By.cssSelector("#addr2")).sendKeys("Side entrance");
	    driver.findElement(By.cssSelector("#city")).sendKeys("Glasgow");
	    driver.findElement(By.cssSelector("#statetext")).sendKeys("United Kingdom");
	    driver.findElement(By.cssSelector("#zipc")).sendKeys("G53 7PH");
	    driver.findElement(By.cssSelector("#phone")).sendKeys("07871374993");
	    driver.findElement(By.cssSelector("#usemail")).sendKeys("test10089@gmail.com");
	    driver.findElement(By.cssSelector("#uspswd")).sendKeys("testing06");
	    driver.findElement(By.cssSelector("#uspswd2")).sendKeys("testing06");
	    driver.findElement(By.cssSelector("#usebillingaddress")).click();
	    driver.findElement(By.cssSelector(".marg-top .success")).click();
	}
	
	public void newCustNextDayFindAdd2(){
		
		 driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
		    driver.findElement(By.cssSelector(".row #fname")).sendKeys("Garry");
		    driver.findElement(By.cssSelector(".row #lname")).sendKeys("Smith");
		    driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
		    Select gender=new Select(driver.findElement(By.cssSelector(".form-select")));
		    gender.selectByVisibleText("Male");
		    Select day=new Select(driver.findElement(By.cssSelector("#billingaddressadd .form-half-input")));
		    day.selectByVisibleText("4");
		    driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
		    Select month=new Select(driver.findElement(By.cssSelector("select[name='remmonth1']")));
		    month.selectByVisibleText("April");
		    driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
		    Select year=new Select(driver.findElement(By.cssSelector("select[name='remyear']")));
		    year.selectByVisibleText("1974");
		    driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
		    Select cntry=new Select(driver.findElement(By.cssSelector("#cntrylist")));
		    cntry.selectByVisibleText("United Kingdom");
		    driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
		    driver.findElement(By.cssSelector("#zipc")).sendKeys("G53 7PH");
		    driver.findElement(By.cssSelector("#js-lookup-submit-btn")).click();
		    Select add= new Select(driver.findElement(By.cssSelector("#js-lookupselect")));
		    add.selectByIndex(11);
		    driver.findElement(By.cssSelector("#phone")).sendKeys("07891378983");
		    driver.findElement(By.cssSelector("#usemail")).sendKeys("test13050@gmail.com");
		    driver.findElement(By.cssSelector("#uspswd")).sendKeys("testing05");
		    driver.findElement(By.cssSelector("#uspswd2")).sendKeys("testing05");
		    driver.findElement(By.cssSelector("#usebillingaddress")).click();
		    driver.findElement(By.cssSelector(".marg-top .success")).click();
		    driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
		
	}
	
	public void existingCustStdDelivery(){
		
		    driver.findElement(By.cssSelector("#email")).sendKeys("test10089@gmail.com");
		    driver.findElement(By.cssSelector("#password")).sendKeys("testing06");
		    driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
		    driver.findElement(By.cssSelector(".return-customer .js-trackoption")).click();
		    driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
			
	}
	
	
}

