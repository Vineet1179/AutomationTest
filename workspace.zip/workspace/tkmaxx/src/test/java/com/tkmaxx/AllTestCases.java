package com.tkmaxx;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.Test;

public class AllTestCases extends Hooks{
@Test
public void searchWithValidData() {
	
	 sl.waitForMilliseconds();
	 bl.enterTheSearchValue();
	 bl.clickOnSearchButton();
	 
	 
	 
}

@Test

public void guestCustNextDayFindAdd(){
	 sl.waitForMilliseconds();
	 bl.enterTheSearchValue();
	 bl.clickOnSearchButton();
     bl.enterTheSearchValue();
     bl.clickOnSearchButton();
     sl.waitForMilliseconds();
     productdetailspage.productDetail();
     sl.waitForMilliseconds();
     productdetailspage.selectQuantity();
     sl.waitForMilliseconds();
     productdetailspage.clickOnaddProductToBasketButton();
     sl.waitForMilliseconds();
     bl.checkOutButton();
     sl.waitForMilliseconds();
     bl.selectGuestCheckoutOptionINCheckoutPage();
     sl.waitForMilliseconds();
     billingpage.enterAllBillingDetails();
     sl.waitForMilliseconds();
     deliverypage.deliveryOptions();
     




// driver.findElement(By.cssSelector(".order-summary-standard")).click();

//driver.findElement(By.cssSelector(".order-summary-storefree")).click();




}



@Test

public void guestCustomerStdManualAdd(){
	
	sl.waitForMilliseconds();
    bl.enterTheSearchValue();
	bl.clickOnSearchButton();
    bl.enterTheSearchValue();
    bl.clickOnSearchButton();
    sl.waitForMilliseconds();
    productdetailspage.productDetail();
    sl.waitForMilliseconds();
    productdetailspage.selectQuantity();
    sl.waitForMilliseconds();
    productdetailspage.clickOnaddProductToBasketButton();
    sl.waitForMilliseconds();
    bl.checkOutButton();
    sl.waitForMilliseconds();
    bl.selectGuestCheckoutOptionINCheckoutPage();
    sl.waitForMilliseconds();
    billingpage.enterBillingAddManually();
    sl.waitForMilliseconds();
    deliverypage.deliveryOptionstd();
    
    
   


}

@Test

public void guestCustomerNextDayStdManual(){
	
	sl.waitForMilliseconds();
    bl.enterTheSearchValue();
    sl.waitForMilliseconds();
    bl.enterTheSearchValue();
    bl.clickOnSearchButton();
    sl.waitForMilliseconds();
    productdetailspage.productDetail();
    sl.waitForPageLoad();
    productdetailspage.selectQuantity();
    sl.waitForMilliseconds();
    productdetailspage.clickOnaddProductToBasketButton();
    sl.waitForMilliseconds();
    bl.checkOutButton();
    sl.waitForMilliseconds();
    bl.selectGuestCheckoutOptionINCheckoutPage();
    sl.waitForMilliseconds();
    billingpage.enterBillingAddManually();
    sl.waitForMilliseconds();
    deliverypage.deliveryOptions();
	
}

@Test

  public void guestCustomerStandardFindAdd(){
	
	 sl.waitForMilliseconds();
	 bl.enterTheSearchValue();
	 bl.clickOnSearchButton();
     bl.enterTheSearchValue();
     bl.clickOnSearchButton();
     sl.waitForMilliseconds();
     productdetailspage.productDetail();
     sl.waitForMilliseconds();
     productdetailspage.selectQuantity();
     sl.waitForMilliseconds();
     productdetailspage.clickOnaddProductToBasketButton();
     sl.waitForMilliseconds();
     bl.checkOutButton();
     sl.waitForMilliseconds();
     bl.selectGuestCheckoutOptionINCheckoutPage();
     sl.waitForMilliseconds();
     billingpage.enterAllBillingDetails();
     sl.waitForMilliseconds();
     deliverypage.deliveryOptionstd();
	
}

@Test

public void newCustStdManualAdd(){
	
	
	sl.waitForMilliseconds();
	 bl.enterTheSearchValue();
	 bl.clickOnSearchButton();
     bl.enterTheSearchValue();
     bl.clickOnSearchButton();
     sl.waitForMilliseconds();
     productdetailspage.productDetail();
     sl.waitForMilliseconds();
     productdetailspage.selectQuantity();
     sl.waitForMilliseconds();
     productdetailspage.clickOnaddProductToBasketButton();
     sl.waitForMilliseconds();
     bl.checkOutButton();
     sl.waitForMilliseconds();
     billingpage.newCustomer();
     sl.waitForMilliseconds();
     billingpage.enterBillingAddManually();
     sl.waitForMilliseconds();
     deliverypage.deliveryOptionstd();
     
}

@Test

public void newCustomerStdFindAdd(){    
	
	 sl.waitForMilliseconds();
	 bl.enterTheSearchValue();
	 bl.clickOnSearchButton();
     bl.enterTheSearchValue();
     bl.clickOnSearchButton();
     sl.waitForMilliseconds();
     productdetailspage.productDetail();
     sl.waitForMilliseconds();
     productdetailspage.selectQuantity();
     sl.waitForMilliseconds();
     productdetailspage.clickOnaddProductToBasketButton();
     sl.waitForMilliseconds();
     bl.checkOutButton();
     sl.waitForMilliseconds();
     billingpage.newCustStdFindAdd1();
     sl.waitForMilliseconds();
     deliverypage.deliveryOptionstd();
	
	
	
}

@Test

public void newCustNextDayManualAdd(){
	sl.waitForMilliseconds();
	bl.enterTheSearchValue();
	bl.clickOnSearchButton();
    bl.enterTheSearchValue();
    bl.clickOnSearchButton();
    sl.waitForMilliseconds();
    productdetailspage.productDetail();
    sl.waitForMilliseconds();
    productdetailspage.selectQuantity();
    sl.waitForMilliseconds();
    productdetailspage.clickOnaddProductToBasketButton();
    sl.waitForMilliseconds();
    bl.checkOutButton();
    sl.waitForMilliseconds();
    billingpage.newCustNextDayManualAdd2();
    sl.waitForMilliseconds();
	deliverypage.deliveryOptions();
	
}

@Test

public void newCustNextDayFindAdd(){
	
	sl.waitForMilliseconds();
	bl.enterTheSearchValue();
	bl.clickOnSearchButton();
    bl.enterTheSearchValue();
    bl.clickOnSearchButton();
    sl.waitForMilliseconds();
    productdetailspage.productDetail();
    sl.waitForMilliseconds();
    productdetailspage.selectQuantity();
    sl.waitForMilliseconds();
    productdetailspage.clickOnaddProductToBasketButton();
    sl.waitForMilliseconds();
    bl.checkOutButton();
    billingpage.newCustNextDayManualAdd2();
    sl.waitForMilliseconds();
    deliverypage.deliveryOptions();
   
	
	
}

@Test

public void exisitingCustomerStdDelivery(){
	
	sl.waitForMilliseconds();
	bl.enterTheSearchValue();
	bl.clickOnSearchButton();
    bl.enterTheSearchValue();
    bl.clickOnSearchButton();
    sl.waitForMilliseconds();
    productdetailspage.productDetail();
    sl.waitForMilliseconds();
    productdetailspage.selectQuantity();
    sl.waitForMilliseconds();
    productdetailspage.clickOnaddProductToBasketButton();
    sl.waitForMilliseconds();
    bl.checkOutButton();
    billingpage.existingCustStdDelivery();
    sl.waitForMilliseconds();
    deliverypage.deliveryOptionstd();
}

public void existingCustomerNextDayDelivery(){
	
	sl.waitForMilliseconds();
	bl.enterTheSearchValue();
	bl.clickOnSearchButton();
    bl.enterTheSearchValue();
    bl.clickOnSearchButton();
    sl.waitForMilliseconds();
    productdetailspage.productDetail();
    sl.waitForMilliseconds();
    productdetailspage.selectQuantity();
    sl.waitForMilliseconds();
    productdetailspage.clickOnaddProductToBasketButton();
    sl.waitForMilliseconds();
    bl.checkOutButton();
    billingpage.existingCustStdDelivery();
    sl.waitForMilliseconds();
    deliverypage.deliveryOptions();
}

public void existingCustomerClickCollect(){
	
	sl.waitForMilliseconds();
	bl.enterTheSearchValue();
	bl.clickOnSearchButton();
    bl.enterTheSearchValue();
    bl.clickOnSearchButton();
    sl.waitForMilliseconds();
    productdetailspage.productDetail();
    sl.waitForMilliseconds();
    productdetailspage.selectQuantity();
    sl.waitForMilliseconds();
    productdetailspage.clickOnaddProductToBasketButton();
    sl.waitForMilliseconds();
    bl.checkOutButton();
    billingpage.existingCustStdDelivery();
    sl.waitForMilliseconds();
    deliverypage.deliveryOptionsClickCollect();
    
	
}

}
