package Web.elements;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class AutoDD {

	public static void main(String[] args) {
		WebDriver driver= new FirefoxDriver();
		driver.get("http://spicejet.com");

		driver.manage().window().maximize();
		driver.findElement(By.id("ctl00_mainContent_ddl_originStation1_CTXT")).click();
		driver.findElement(By.linkText("Goa (GOI)")).click();
		

		
				
		
	
		
		

	}

}
