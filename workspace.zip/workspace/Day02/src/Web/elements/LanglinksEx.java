package Web.elements;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;

public class LanglinksEx {

	public static void main(String[] args) {
		WebDriver driver= new FirefoxDriver();
		driver.manage().window().maximize();
		driver.get("http://google.co.in");
		WebElement lang=driver.findElement(By.id("eEe"));
		List<WebElement> links= lang.findElements(By.tagName("a"));
		System.out.println(links.size());
		for(WebElement a: links){
			System.out.println(a.getText());
			
		}
		
		

	}

}
