package Web.elements;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;

public class ButtonEx01 {

	public static void main(String[] args) {
		WebDriver driver= new FirefoxDriver();
		driver.manage().window().maximize();
		driver.get("http://facebook.com");
		
		// to create reference object for login button
		WebElement wb= driver.findElement(By.id("u_0_l"));
		// to check object is enabled or not
		if(wb.isEnabled()){
			System.out.println("login Button is enabled");
			System.out.println("Obj name is:"+wb.getAttribute("value"));
			wb.click();
			
			
		}
		

	}

}
