package Web.elements;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;

public class CheckboEx02 {

	public static void main(String[] args) {
		WebDriver driver= new FirefoxDriver();
		driver.manage().window().maximize();
		driver.get("http://echoecho.com/htmlforms09.htm");
	List<WebElement> chks=	driver.findElements(By.name("Checkbox"));
	
	System.out.println("number of checkboxes are:"+chks.size());
		for (WebElement chk:chks){
			if(!chk.isSelected());
			chk.click();
			
		}

	}

}