package Web.elements;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;

public class WebeditEx01 {

	public static void main(String[] args) {

		WebDriver driver= new FirefoxDriver();
		driver.manage().window().maximize();
		driver.get("http://facebook.com");
		String uid="InsightQ";
		
	WebElement	we=driver.findElement(By.id("email"));
		
		we.click();
		we.sendKeys(uid);
		String userid=we.getAttribute("value");
		we.clear();
		if(userid.equals(uid))  {
		System.out.println("entered value existing");
		}else {
		System.out.println("values are mismatching");
		
			
		}
	}
}
		
		
		
		
		

	


