package Web.elements;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class CheckboxEx01 {

	public static void main(String[] args) {
	WebDriver driver= new FirefoxDriver();
	driver.manage().window().maximize();
	driver.get("https://login.salesforce.com");	
	
	driver.findElement(By.id("rememberUn")).click();
	

	}

}
