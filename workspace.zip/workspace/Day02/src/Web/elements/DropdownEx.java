package Web.elements;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;

public class DropdownEx {

	public static void main(String[] args) {
		WebDriver driver= new FirefoxDriver();
		driver.manage().window().maximize();
		driver.get("http://newtours.demoaut.com");
		driver.findElement(By.linkText("REGISTER")).click();
		Select we= new Select(driver.findElement(By.name("country")));
        we.selectByVisibleText("INDIA");
        we.selectByIndex(0);
        we.selectByValue("92");
        List<WebElement> options= we.getOptions();
        System.out.println("number of values are:"+options.size());
        for(WebElement option: options) {
        	System.out.println(option.getText());
         	
        }
        
        
        
     
		
		
		
	}

}
