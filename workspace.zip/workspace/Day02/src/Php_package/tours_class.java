package Php_package;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;

public class tours_class {

	public static void main(String[] args) throws InterruptedException {
		WebDriver driver=new FirefoxDriver();
		driver.manage().window().maximize();
		driver.get("http://phptravels.net/admin");
			
		//Admin Login***************
		driver.findElement(By.xpath("html/body/div/form[1]/div[1]/input[1]")).sendKeys("admin@phptravels.com");
		driver.findElement(By.xpath("html/body/div/form[1]/div[1]/input[2]")).sendKeys("demoadmin");
		driver.findElement(By.xpath("html/body/div/form[1]/button")).click();
		//Tours********
		Thread.sleep(10000);
		driver.findElement(By.xpath("html/body/div[2]/aside/div/div[1]/div[4]/div/ul/li[8]/a/span")).click();
		Thread.sleep(10000);
		driver.findElement(By.xpath("html/body/div[2]/aside/div/div[1]/div[4]/div/ul/li[8]/ul/li[1]/a")).click();
		Thread.sleep(10000);
		driver.findElement(By.xpath("html/body/div[2]/div/div/div/form/button")).click();
	
		
		

	}

}
