package Php_package;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;

public class php_class {

	public static void main(String[] args) throws InterruptedException {
		WebDriver driver= new FirefoxDriver();
		driver.get("http://phptravels.net/admin");
		driver.manage().window().maximize();
		//Admin login ********************
		driver.findElement(By.name("email")).sendKeys("admin@phptravels.com");
		driver.findElement(By.name("password")).sendKeys("demoadmin");
		driver.findElement(By.xpath("html/body/div/form[1]/button")).click();
		//Accounts*********
		Thread.sleep(10000);
		driver.findElement(By.xpath("html/body/div[2]/aside/div/div[1]/div[4]/div/ul/li[4]/a/span")).click();
		Thread.sleep(10000);
		driver.findElement(By.xpath("html/body/div[2]/aside/div/div[1]/div[4]/div/ul/li[4]/ul/li[3]/a")).click();
		Thread.sleep(10000);
		driver.findElement(By.xpath("html/body/div[2]/div/div/div/form/button")).click();
		driver.findElement(By.xpath("html/body/div[2]/div/div/form/div/div[2]/div/div[1]/div/input")).sendKeys("Vineet");
		driver.findElement(By.xpath("html/body/div[2]/div/div/form/div/div[2]/div/div[2]/div/input")).sendKeys("Muley");
		driver.findElement(By.xpath("html/body/div[2]/div/div/form/div/div[2]/div/div[3]/div/input")).sendKeys("asdf@gmail.com");
		driver.findElement(By.xpath("html/body/div[2]/div/div/form/div/div[2]/div/div[4]/div/input")).sendKeys("mindq123");
		driver.findElement(By.xpath("html/body/div[2]/div/div/form/div/div[2]/div/div[5]/div/input")).sendKeys("07742183342");
		
		 new Select(driver.findElement(By.xpath("//select[@class='chosen-select select2-offscreen']"))).selectByVisibleText("India");
		driver.findElement(By.xpath("html/body/div[2]/div/div/form/div/div[2]/div/div[8]/div/input")).sendKeys("45 Cardwel St.");
		driver.findElement(By.xpath("html/body/div[2]/div/div/form/div/div[2]/div/div[9]/div/input")).sendKeys("Bradford");
		driver.findElement(By.xpath(".//*[@id='content']/form/div/div[2]/div/div[13]/div/div/label/div/ins")).click();
		Thread.sleep(5000);
		driver.findElement(By.xpath("html/body/div[2]/div/div/form/div/div[3]/button")).click();
		
		
		
	
				 
		
		

	}

}
