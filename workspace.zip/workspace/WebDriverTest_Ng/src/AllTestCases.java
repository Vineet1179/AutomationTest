import org.junit.Test;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;

public class AllTestCases {

	@BeforeTest
	public void start(){
	    System.out.println(" I am in Before method");
}
 @Test
 public void test1(){
	 System.out.println(" I am in Test1 method");
 }
	 
  @AfterTest
  public void close(){
	 System.out.println(" I am in After method");
	 
  }
  
}